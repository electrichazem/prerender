<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Get all questions
    $questions_query = "
        SELECT id, title, description_html, hint, display_order, is_active, created_at
        FROM questions 
        ORDER BY display_order ASC, created_at ASC
    ";
    
    $stmt = $db->prepare($questions_query);
    $stmt->execute();
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get submission counts for each question
    foreach ($questions as &$question) {
        $count_query = "
            SELECT 
                COUNT(*) as total_submissions,
                COUNT(CASE WHEN status = 'accepted' THEN 1 END) as accepted_count,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                COUNT(CASE WHEN photo_status = 'accepted' THEN 1 END) as completed_count,
                COUNT(CASE WHEN photo_status = 'pending' THEN 1 END) as photo_pending_count
            FROM submissions 
            WHERE question_id = :question_id
        ";
        $stmt = $db->prepare($count_query);
        $stmt->bindParam(':question_id', $question['id'], PDO::PARAM_INT);
        $stmt->execute();
        $counts = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $question['total_submissions'] = (int)$counts['total_submissions'];
        $question['accepted_count'] = (int)$counts['accepted_count'];
        $question['pending_count'] = (int)$counts['pending_count'];
        $question['completed_count'] = (int)$counts['completed_count'];
        $question['photo_pending_count'] = (int)$counts['photo_pending_count'];
    }

    echo json_encode([
        "success" => true,
        "questions" => $questions
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>