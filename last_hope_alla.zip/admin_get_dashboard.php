<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Get dashboard statistics
    // Total teams
    $teams_query = "SELECT COUNT(*) as total_teams FROM teams WHERE is_active = 1";
    $stmt = $db->prepare($teams_query);
    $stmt->execute();
    $teams_result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Total questions
    $questions_query = "SELECT COUNT(*) as total_questions FROM questions WHERE is_active = 1";
    $stmt = $db->prepare($questions_query);
    $stmt->execute();
    $questions_result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Pending submissions
    $pending_query = "SELECT COUNT(*) as pending_submissions FROM submissions WHERE status = 'pending'";
    $stmt = $db->prepare($pending_query);
    $stmt->execute();
    $pending_result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Total submissions
    $total_submissions_query = "SELECT COUNT(*) as total_submissions FROM submissions";
    $stmt = $db->prepare($total_submissions_query);
    $stmt->execute();
    $total_submissions_result = $stmt->fetch(PDO::FETCH_ASSOC);

    // Recent submissions (last 10)
    $recent_submissions_query = "
        SELECT s.id, s.submitted_answer, s.status, s.submitted_at, 
               t.name as team_name, q.title as question_title
        FROM submissions s
        JOIN teams t ON s.team_id = t.id
        JOIN questions q ON s.question_id = q.id
        ORDER BY s.submitted_at DESC
        LIMIT 10
    ";
    $stmt = $db->prepare($recent_submissions_query);
    $stmt->execute();
    $recent_submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Team progress overview
    $team_progress_query = "
        SELECT 
            COUNT(DISTINCT t.id) as total_teams,
            COUNT(DISTINCT CASE WHEN s.status = 'accepted' THEN s.team_id END) as teams_with_solutions,
            AVG(CASE WHEN s.status = 'accepted' THEN 1 ELSE 0 END) as avg_completion_rate
        FROM teams t
        LEFT JOIN submissions s ON t.id = s.team_id
        WHERE t.is_active = 1
    ";
    $stmt = $db->prepare($team_progress_query);
    $stmt->execute();
    $team_progress = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "stats" => [
            "total_teams" => (int)$teams_result['total_teams'],
            "total_questions" => (int)$questions_result['total_questions'],
            "pending_submissions" => (int)$pending_result['pending_submissions'],
            "total_submissions" => (int)$total_submissions_result['total_submissions'],
            "teams_with_solutions" => (int)$team_progress['teams_with_solutions'],
            "avg_completion_rate" => round((float)$team_progress['avg_completion_rate'] * 100, 1)
        ],
        "recent_submissions" => $recent_submissions
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>