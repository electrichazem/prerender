<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$submission_id = isset($input['submission_id']) ? intval($input['submission_id']) : 0;
$action = isset($input['action']) ? $input['action'] : ''; // 'accept' or 'reject'
$admin_notes = isset($input['admin_notes']) ? trim($input['admin_notes']) : '';
$review_type = isset($input['review_type']) ? $input['review_type'] : 'answer'; // 'answer' or 'photo'

if ($submission_id <= 0 || !in_array($action, ['accept', 'reject']) || !in_array($review_type, ['answer', 'photo'])) {
    http_response_code(400);
    echo json_encode(["error" => "Valid submission ID, action, and review type are required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    $admin_id = $admin['id'];

    // Get submission details
    $submission_query = "
        SELECT s.id, s.team_id, s.question_id, s.status, s.photo_status, s.photo_filename
        FROM submissions s 
        WHERE s.id = :submission_id
    ";
    $stmt = $db->prepare($submission_query);
    $stmt->bindParam(':submission_id', $submission_id, PDO::PARAM_INT);
    $stmt->execute();
    $submission = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$submission) {
        http_response_code(404);
        echo json_encode(["error" => "Submission not found"]);
        exit;
    }

    // Check if reviewing answer or photo
    if ($review_type === 'answer') {
        if ($submission['status'] !== 'pending') {
            http_response_code(400);
            echo json_encode(["error" => "Answer submission already reviewed"]);
            exit;
        }
        
        // Update answer submission status
        $new_status = $action === 'accept' ? 'accepted' : 'rejected';
        
        $update_query = "
            UPDATE submissions 
            SET status = :status, 
                reviewed_at = NOW(), 
                reviewed_by = :admin_id,
                admin_notes = :admin_notes
            WHERE id = :submission_id
        ";
        
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':status', $new_status, PDO::PARAM_STR);
        $stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $stmt->bindParam(':admin_notes', $admin_notes, PDO::PARAM_STR);
        $stmt->bindParam(':submission_id', $submission_id, PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Answer submission {$action}ed successfully",
            "submission_id" => $submission_id,
            "new_status" => $new_status,
            "review_type" => "answer"
        ]);
        
    } else { // photo review
        if ($submission['photo_status'] !== 'pending') {
            http_response_code(400);
            echo json_encode(["error" => "Photo submission already reviewed"]);
            exit;
        }
        
        // Update photo submission status
        $new_photo_status = $action === 'accept' ? 'accepted' : 'rejected';
        
        $update_query = "
            UPDATE submissions 
            SET photo_status = :photo_status, 
                photo_reviewed_at = NOW(), 
                photo_reviewed_by = :admin_id,
                photo_admin_notes = :admin_notes
            WHERE id = :submission_id
        ";
        
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':photo_status', $new_photo_status, PDO::PARAM_STR);
        $stmt->bindParam(':admin_id', $admin_id, PDO::PARAM_INT);
        $stmt->bindParam(':admin_notes', $admin_notes, PDO::PARAM_STR);
        $stmt->bindParam(':submission_id', $submission_id, PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Photo submission {$action}ed successfully",
            "submission_id" => $submission_id,
            "new_photo_status" => $new_photo_status,
            "review_type" => "photo",
            "question_completed" => $action === 'accept'
        ]);
    }

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>