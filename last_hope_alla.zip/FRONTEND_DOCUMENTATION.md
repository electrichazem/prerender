# Frontend Integration Guide - Two-Phase Completion System

## Overview
The robotics workshop now supports a two-phase completion system:
1. **Phase 1**: Submit answer → Admin accepts → Hint unlocked
2. **Phase 2**: Go to hint location → Take photo → Admin accepts → Question completed

---

## 🆕 New API Endpoints

### 1. Submit Photo
**Endpoint**: `POST /submit_photo.php`
**Authentication**: Bearer token required

**Request Body**:
```json
{
  "question_id": 123,
  "photo_data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ..."
}
```

**Response**:
```json
{
  "success": true,
  "message": "Photo submitted successfully and pending review",
  "filename": "team_5_question_123_1698123456.jpg",
  "submission_id": 456
}
```

**Error Cases**:
- `403`: Hint not unlocked yet (answer must be accepted first)
- `409`: Photo already submitted/accepted
- `400`: Invalid photo data

---

### 2. Get Photo (Admin)
**Endpoint**: `GET /admin_get_photo.php?submission_id=456`
**Authentication**: Admin Bearer token required

**Response**:
```json
{
  "success": true,
  "submission": {
    "id": 456,
    "team_name": "Team Alpha",
    "question_title": "Robot Assembly Challenge",
    "photo_status": "pending",
    "photo_submitted_at": "2023-10-22 12:30:45",
    "photo_data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ...",
    "filename": "team_5_question_123_1698123456.jpg"
  }
}
```

---

## 🔄 Updated API Endpoints

### 1. Review Submission (Updated)
**Endpoint**: `POST /admin_review_submission.php`

**New Request Body**:
```json
{
  "submission_id": 456,
  "action": "accept", // or "reject"
  "admin_notes": "Great photo! Component clearly visible.",
  "review_type": "photo" // NEW: "answer" or "photo"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Photo submission accepted successfully",
  "submission_id": 456,
  "new_photo_status": "accepted",
  "review_type": "photo",
  "question_completed": true
}
```

---

### 2. Get Team Progress (Updated)
**Endpoint**: `GET /get_team_progress.php`

**New Response Structure**:
```json
{
  "success": true,
  "team_name": "Team Alpha",
  "progress": {
    "total_questions": 10,
    "completed": 3,        // NEW: Fully completed questions
    "hint_unlocked": 2,     // NEW: Hint unlocked, can submit photo
    "pending_answer": 1,    // NEW: Answer pending review
    "pending_photo": 1,     // NEW: Photo pending review
    "available": 3
  },
  "questions": [
    {
      "id": 123,
      "title": "Robot Assembly Challenge",
      "status": "hint_unlocked",     // NEW statuses
      "can_submit_answer": false,    // NEW
      "can_submit_photo": true,      // NEW
      "answer_status": "accepted",    // NEW
      "photo_status": null           // NEW
    }
  ],
  "unlocked_hints": [
    {
      "question_id": 123,
      "title": "Robot Assembly Challenge",
      "hint": "Look for the red component near the main circuit board",
      "photo_status": "pending"      // NEW
    }
  ]
}
```

---

### 3. Get Question Detail (Updated)
**Endpoint**: `GET /get_question_detail.php?question_id=123`

**New Response Structure**:
```json
{
  "success": true,
  "question": {
    "id": 123,
    "title": "Robot Assembly Challenge",
    "status": "hint_unlocked",       // NEW: Overall status
    "can_submit_answer": false,      // NEW
    "can_submit_photo": true,        // NEW
    "submitted_answer": "The red resistor",
    "admin_notes": "Correct!",
    "photo_filename": "team_5_question_123_1698123456.jpg", // NEW
    "photo_admin_notes": null,       // NEW
    "answer_status": "accepted",     // NEW
    "photo_status": "pending"        // NEW
  }
}
```

---

### 4. Get Submissions (Admin - Updated)
**Endpoint**: `GET /admin_get_submissions.php`

**New Response Fields**:
```json
{
  "success": true,
  "submissions": [
    {
      "id": 456,
      "submitted_answer": "The red resistor",
      "status": "accepted",
      "photo_filename": "team_5_question_123_1698123456.jpg", // NEW
      "photo_status": "pending",     // NEW
      "photo_submitted_at": "2023-10-22 12:30:45", // NEW
      "photo_admin_notes": null,     // NEW
      "team_name": "Team Alpha",
      "question_title": "Robot Assembly Challenge"
    }
  ]
}
```

---

### 5. Get Questions (Admin - Updated)
**Endpoint**: `GET /admin_get_questions.php`

**New Response Fields**:
```json
{
  "success": true,
  "questions": [
    {
      "id": 123,
      "title": "Robot Assembly Challenge",
      "total_submissions": 5,
      "accepted_count": 3,
      "pending_count": 1,
      "completed_count": 2,           // NEW: Fully completed
      "photo_pending_count": 1        // NEW: Photos pending review
    }
  ]
}
```

---

## 🎨 Frontend Implementation Guide

### 1. Question Status Display
```javascript
const getQuestionStatusBadge = (question) => {
  switch(question.status) {
    case 'available':
      return { text: 'Available', color: 'green', icon: 'play' };
    case 'pending_answer':
      return { text: 'Answer Pending', color: 'yellow', icon: 'clock' };
    case 'hint_unlocked':
      return { text: 'Take Photo', color: 'blue', icon: 'camera' };
    case 'pending_photo':
      return { text: 'Photo Pending', color: 'orange', icon: 'camera-clock' };
    case 'completed':
      return { text: 'Completed', color: 'purple', icon: 'check-circle' };
    case 'globally_completed':
      return { text: 'Solved by Another Team', color: 'red', icon: 'lock' };
    default:
      return { text: 'Unknown', color: 'gray', icon: 'question' };
  }
};
```

### 2. Action Buttons
```javascript
const getAvailableActions = (question) => {
  const actions = [];
  
  if (question.can_submit_answer) {
    actions.push({
      type: 'submit_answer',
      text: 'Submit Answer',
      icon: 'send',
      color: 'primary'
    });
  }
  
  if (question.can_submit_photo) {
    actions.push({
      type: 'submit_photo',
      text: 'Take Photo',
      icon: 'camera',
      color: 'secondary'
    });
  }
  
  return actions;
};
```

### 3. Photo Upload Component
```javascript
const PhotoUploadComponent = ({ questionId, onSuccess }) => {
  const [photo, setPhoto] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handlePhotoCapture = (imageData) => {
    setPhoto(imageData);
  };

  const submitPhoto = async () => {
    if (!photo) return;
    
    setUploading(true);
    try {
      const response = await fetch('/submit_photo.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${teamToken}`
        },
        body: JSON.stringify({
          question_id: questionId,
          photo_data: photo
        })
      });
      
      const result = await response.json();
      if (result.success) {
        onSuccess(result);
      } else {
        alert(result.error);
      }
    } catch (error) {
      alert('Upload failed: ' + error.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="photo-upload">
      <CameraCapture onCapture={handlePhotoCapture} />
      {photo && (
        <div className="photo-preview">
          <img src={photo} alt="Captured photo" />
          <button onClick={submitPhoto} disabled={uploading}>
            {uploading ? 'Uploading...' : 'Submit Photo'}
          </button>
        </div>
      )}
    </div>
  );
};
```

### 4. Progress Dashboard
```javascript
const ProgressDashboard = ({ progress }) => {
  return (
    <div className="progress-dashboard">
      <div className="progress-stats">
        <div className="stat completed">
          <span className="count">{progress.completed}</span>
          <span className="label">Completed</span>
        </div>
        <div className="stat hint-unlocked">
          <span className="count">{progress.hint_unlocked}</span>
          <span className="label">Take Photos</span>
        </div>
        <div className="stat pending-answer">
          <span className="count">{progress.pending_answer}</span>
          <span className="label">Answer Pending</span>
        </div>
        <div className="stat pending-photo">
          <span className="count">{progress.pending_photo}</span>
          <span className="label">Photo Pending</span>
        </div>
        <div className="stat available">
          <span className="count">{progress.available}</span>
          <span className="label">Available</span>
        </div>
      </div>
    </div>
  );
};
```

---

## 🔧 Admin Panel Updates

### 1. Submission Review Interface
```javascript
const SubmissionReview = ({ submission, onReview }) => {
  const [reviewType, setReviewType] = useState('answer');
  const [action, setAction] = useState('accept');
  const [notes, setNotes] = useState('');

  const handleReview = async () => {
    const response = await fetch('/admin_review_submission.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      },
      body: JSON.stringify({
        submission_id: submission.id,
        action: action,
        admin_notes: notes,
        review_type: reviewType
      })
    });
    
    const result = await response.json();
    if (result.success) {
      onReview(result);
    }
  };

  return (
    <div className="submission-review">
      <div className="review-tabs">
        <button 
          className={reviewType === 'answer' ? 'active' : ''}
          onClick={() => setReviewType('answer')}
        >
          Review Answer
        </button>
        {submission.photo_filename && (
          <button 
            className={reviewType === 'photo' ? 'active' : ''}
            onClick={() => setReviewType('photo')}
          >
            Review Photo
          </button>
        )}
      </div>
      
      {reviewType === 'answer' ? (
        <div className="answer-review">
          <p><strong>Answer:</strong> {submission.submitted_answer}</p>
        </div>
      ) : (
        <div className="photo-review">
          <img 
            src={`/admin_get_photo.php?submission_id=${submission.id}`}
            alt="Submitted photo"
          />
        </div>
      )}
      
      <div className="review-actions">
        <select value={action} onChange={(e) => setAction(e.target.value)}>
          <option value="accept">Accept</option>
          <option value="reject">Reject</option>
        </select>
        <textarea 
          value={notes} 
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Admin notes..."
        />
        <button onClick={handleReview}>Submit Review</button>
      </div>
    </div>
  );
};
```

---

## 📱 Mobile Considerations

### Camera Integration
```javascript
// For mobile web apps
const capturePhoto = () => {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'image/*';
  input.capture = 'environment'; // Use back camera
  
  input.onchange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      setPhoto(e.target.result);
    };
    reader.readAsDataURL(file);
  };
  
  input.click();
};
```

---

## 🎯 Key Implementation Points

1. **Status Management**: Update your state management to handle the new statuses
2. **Photo Storage**: Photos are stored in `uploads/photos/` directory
3. **Base64 Encoding**: Photos are transmitted as base64 data URLs
4. **Two-Phase Flow**: Ensure UI clearly shows the progression from answer → photo → completion
5. **Admin Workflow**: Admins now have separate review processes for answers and photos
6. **Error Handling**: Handle new error cases like "hint not unlocked yet"

---

## 🚀 Migration Steps

1. **Update API calls** to use new endpoints and parameters
2. **Modify state management** to handle new statuses
3. **Add photo capture/upload components**
4. **Update admin review interface** for two-phase reviews
5. **Test the complete flow** from answer submission to photo completion

This documentation should help your frontend team implement the new two-phase completion system seamlessly!
