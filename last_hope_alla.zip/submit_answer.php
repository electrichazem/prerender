<?php
include 'config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$question_id = isset($input['question_id']) ? intval($input['question_id']) : 0;
$answer = isset($input['answer']) ? trim($input['answer']) : '';

if ($question_id <= 0 || empty($answer)) {
    http_response_code(400);
    echo json_encode(["error" => "Question ID and answer are required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token and get team ID
    $team_query = "SELECT id FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Check if question exists, is active, and not globally completed
    $question_query = "
        SELECT q.id,
               CASE WHEN EXISTS(
                   SELECT 1 FROM submissions s 
                   WHERE s.question_id = q.id AND s.photo_status = 'accepted'
               ) THEN 1 ELSE 0 END as is_globally_completed
        FROM questions q 
        WHERE q.id = :question_id AND q.is_active = 1";
    $stmt = $db->prepare($question_query);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $question = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$question) {
        http_response_code(404);
        echo json_encode(["error" => "Question not found or inactive"]);
        exit;
    }

    // Check if question is globally completed by another team
    if ($question['is_globally_completed']) {
        http_response_code(403);
        echo json_encode(["error" => "Question has been completed by another team"]);
        exit;
    }

    // Check if team already has a submission for this question
    $existing_submission_query = "SELECT id, status FROM submissions 
                                WHERE team_id = :team_id AND question_id = :question_id";
    $stmt = $db->prepare($existing_submission_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $existing_submission = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing_submission) {
        if ($existing_submission['status'] === 'accepted') {
            http_response_code(409);
            echo json_encode(["error" => "Question already solved"]);
            exit;
        } else if ($existing_submission['status'] === 'pending') {
            http_response_code(409);
            echo json_encode(["error" => "Answer already submitted and pending review"]);
            exit;
        }
        // If rejected, allow resubmission by updating existing record
    }

    // Insert or update submission
    if ($existing_submission && $existing_submission['status'] === 'rejected') {
        // Update rejected submission
        $update_query = "UPDATE submissions 
                        SET submitted_answer = :answer, status = 'pending', submitted_at = NOW() 
                        WHERE id = :submission_id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':answer', $answer, PDO::PARAM_STR);
        $stmt->bindParam(':submission_id', $existing_submission['id'], PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Insert new submission
        $insert_query = "INSERT INTO submissions (team_id, question_id, submitted_answer, status) 
                        VALUES (:team_id, :question_id, :answer, 'pending')";
        $stmt = $db->prepare($insert_query);
        $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
        $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
        $stmt->bindParam(':answer', $answer, PDO::PARAM_STR);
        $stmt->execute();
    }

    echo json_encode([
        "success" => true,
        "message" => "Answer submitted successfully and pending review"
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>