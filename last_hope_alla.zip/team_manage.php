<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$team_code = isset($input['team_code']) ? trim($input['team_code']) : '';
$action = isset($input['action']) ? trim($input['action']) : '';

if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Team code is required"]);
    exit;
}

if (!in_array($action, ['join', 'refresh', 'logout'])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action. Use 'join', 'refresh', or 'logout'"]);
    exit;
}

// Sanitize team code (alphanumeric only)
$team_code = preg_replace('/[^a-zA-Z0-9]/', '', $team_code);
if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid team code format"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Check if any active questions exist
    $check_questions_query = "SELECT COUNT(*) as active_count FROM questions WHERE is_active = 1";
    $stmt = $db->prepare($check_questions_query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['active_count'] == 0) {
        http_response_code(403);
        echo json_encode(["error" => "Game has not started or all questions have been solved"]);
        exit;
    }

    // Check if team exists
    $check_team_query = "SELECT id, name, token FROM teams WHERE code = :code AND is_active = 1";
    $stmt = $db->prepare($check_team_query);
    $stmt->bindParam(':code', $team_code, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(404);
        echo json_encode(["error" => "Team not found or inactive"]);
        exit;
    }

    if ($action === 'join') {
        // Generate new token (allow multiple joins)
        $token = bin2hex(random_bytes(32));
        
        // Update team with new token
        $update_query = "UPDATE teams SET token = :token, last_activity = NOW() WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':id', $team['id'], PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Team successfully joined the game",
            "team_name" => $team['name'],
            "token" => $token,
            "action" => "joined"
        ]);

    } elseif ($action === 'refresh') {
        // Only refresh if team already has a token
        if (empty($team['token'])) {
            http_response_code(400);
            echo json_encode(["error" => "Team must join first before refreshing token"]);
            exit;
        }

        // Generate new token
        $token = bin2hex(random_bytes(32));
        
        // Update team with new token
        $update_query = "UPDATE teams SET token = :token, last_activity = NOW() WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':token', $token, PDO::PARAM_STR);
        $stmt->bindParam(':id', $team['id'], PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Team token refreshed successfully",
            "team_name" => $team['name'],
            "token" => $token,
            "action" => "refreshed"
        ]);

    } elseif ($action === 'logout') {
        // Clear team token
        $update_query = "UPDATE teams SET token = NULL, last_activity = NOW() WHERE id = :id";
        $stmt = $db->prepare($update_query);
        $stmt->bindParam(':id', $team['id'], PDO::PARAM_INT);
        $stmt->execute();

        echo json_encode([
            "success" => true,
            "message" => "Team logged out successfully",
            "team_name" => $team['name'],
            "action" => "logged_out"
        ]);
    }

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>
