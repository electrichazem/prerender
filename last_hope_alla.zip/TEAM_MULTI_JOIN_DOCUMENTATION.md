# Team Multi-Join System Documentation

## Overview
The team system has been updated to allow teams to join multiple times, change their tokens, and manage their sessions independently. Teams can now rejoin the game, refresh their tokens, and logout as needed.

## New Features

### 1. Enhanced Team Entry (`enter_game.php`)
Teams can now join multiple times and get new tokens each time.

**Endpoint:** `POST /enter_game.php`

**Request Body:**
```json
{
    "team_code": "TEAM123"
}
```

**Response (First Join):**
```json
{
    "success": true,
    "message": "Team successfully entered the game",
    "team_name": "Team Alpha",
    "token": "generated_token_here"
}
```

**Response (Rejoin):**
```json
{
    "success": true,
    "message": "Team successfully rejoined the game",
    "team_name": "Team Alpha",
    "token": "new_generated_token_here"
}
```

### 2. Team Token Management (`team_manage.php`)
Allows teams to join, refresh tokens, or logout.

**Endpoint:** `POST /team_manage.php`

**Request Body:**
```json
{
    "team_code": "TEAM123",
    "action": "join"  // "join", "refresh", or "logout"
}
```

**Actions:**

#### Join Action
```json
{
    "team_code": "TEAM123",
    "action": "join"
}
```
**Response:**
```json
{
    "success": true,
    "message": "Team successfully joined the game",
    "team_name": "Team Alpha",
    "token": "new_token_here",
    "action": "joined"
}
```

#### Refresh Token Action
```json
{
    "team_code": "TEAM123",
    "action": "refresh"
}
```
**Response:**
```json
{
    "success": true,
    "message": "Team token refreshed successfully",
    "team_name": "Team Alpha",
    "token": "new_refreshed_token",
    "action": "refreshed"
}
```

#### Logout Action
```json
{
    "team_code": "TEAM123",
    "action": "logout"
}
```
**Response:**
```json
{
    "success": true,
    "message": "Team logged out successfully",
    "team_name": "Team Alpha",
    "action": "logged_out"
}
```

### 3. Team Status Check (`team_status.php`)
Check if a team is active and has a token.

**Endpoint:** `POST /team_status.php`

**Request Body:**
```json
{
    "team_code": "TEAM123"
}
```

**Response (Active Team):**
```json
{
    "success": true,
    "team": {
        "id": 1,
        "name": "Team Alpha",
        "code": "TEAM123",
        "status": "active",
        "has_token": true,
        "last_activity": "2024-01-15 14:30:00"
    },
    "message": "Team is active with token"
}
```

**Response (Inactive Team):**
```json
{
    "success": true,
    "team": {
        "id": 1,
        "name": "Team Alpha",
        "code": "TEAM123",
        "status": "inactive",
        "has_token": false,
        "last_activity": "2024-01-15 12:00:00"
    },
    "message": "Team is inactive (no token)"
}
```

## Updated Behavior

### Original `enter_game.php` Changes:
- ✅ **Removed single-join restriction** - Teams can now join multiple times
- ✅ **Token overwriting** - New tokens replace old ones
- ✅ **Dynamic messages** - Different messages for first join vs rejoin
- ✅ **Simplified logic** - No more race condition handling

### Key Benefits:
1. **Multiple Sessions** - Teams can join from different devices
2. **Token Refresh** - Teams can get new tokens without losing progress
3. **Logout Capability** - Teams can logout and clear their tokens
4. **Status Checking** - Easy way to check if team is active
5. **Flexible Management** - Teams have full control over their sessions

## API Endpoints Summary

| Endpoint | Method | Purpose | Input |
|----------|--------|---------|-------|
| `/enter_game.php` | POST | Join/rejoin game | `team_code` |
| `/team_manage.php` | POST | Manage team sessions | `team_code`, `action` |
| `/team_status.php` | POST | Check team status | `team_code` |
| `/submit_answer.php` | POST | Submit answers | `Authorization: Bearer <token>` |
| `/submit_photo.php` | POST | Submit photos | `Authorization: Bearer <token>` |
| `/get_team_progress.php` | GET | Get progress | `Authorization: Bearer <token>` |
| `/get_question_detail.php` | GET | Get question | `Authorization: Bearer <token>` |
| `/get_hints.php` | GET | Get hints | `Authorization: Bearer <token>` |

## Usage Examples

### Team Workflow:
1. **First Join:**
   ```bash
   POST /enter_game.php
   {"team_code": "TEAM123"}
   # Returns: token for first time
   ```

2. **Rejoin from Different Device:**
   ```bash
   POST /enter_game.php
   {"team_code": "TEAM123"}
   # Returns: new token (old token becomes invalid)
   ```

3. **Refresh Token:**
   ```bash
   POST /team_manage.php
   {"team_code": "TEAM123", "action": "refresh"}
   # Returns: new token
   ```

4. **Check Status:**
   ```bash
   POST /team_status.php
   {"team_code": "TEAM123"}
   # Returns: current status
   ```

5. **Logout:**
   ```bash
   POST /team_manage.php
   {"team_code": "TEAM123", "action": "logout"}
   # Returns: confirmation, token cleared
   ```

## Security Notes

- **Token Uniqueness** - Each token is unique and 64 characters long
- **Token Replacement** - New tokens immediately invalidate old ones
- **Activity Tracking** - `last_activity` is updated on each action
- **Game State Validation** - All actions check if game is active
- **Input Sanitization** - Team codes are sanitized (alphanumeric only)

## Migration Notes

- ✅ **Backward Compatible** - Existing tokens continue to work
- ✅ **No Database Changes** - Uses existing `teams` table structure
- ✅ **Enhanced Functionality** - All existing features remain intact
- ✅ **Improved UX** - Teams can now manage their sessions flexibly
