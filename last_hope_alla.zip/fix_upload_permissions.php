<?php
// Photo Upload Permission Fix Script
// Run this script on your DigitalOcean droplet to fix upload permissions

echo "=== Photo Upload Permission Fix ===\n";

$upload_dir = __DIR__ . '/uploads/photos/';

echo "Checking upload directory: $upload_dir\n";

// Check if directory exists
if (!is_dir($upload_dir)) {
    echo "Directory doesn't exist. Creating...\n";
    if (mkdir($upload_dir, 0755, true)) {
        echo "✅ Directory created successfully\n";
    } else {
        echo "❌ Failed to create directory\n";
        exit(1);
    }
} else {
    echo "✅ Directory exists\n";
}

// Check permissions
echo "Checking permissions...\n";
echo "Directory readable: " . (is_readable($upload_dir) ? "✅ Yes" : "❌ No") . "\n";
echo "Directory writable: " . (is_writable($upload_dir) ? "✅ Yes" : "❌ No") . "\n";

// Try to create a test file
$test_file = $upload_dir . 'test_permissions.txt';
echo "Testing file creation...\n";

if (file_put_contents($test_file, 'test') !== false) {
    echo "✅ File creation successful\n";
    
    // Clean up test file
    if (unlink($test_file)) {
        echo "✅ Test file cleaned up\n";
    } else {
        echo "⚠️  Could not delete test file\n";
    }
} else {
    echo "❌ File creation failed\n";
}

// Show current permissions
echo "\nCurrent directory permissions:\n";
echo "Owner: " . fileowner($upload_dir) . "\n";
echo "Group: " . filegroup($upload_dir) . "\n";
echo "Mode: " . substr(sprintf('%o', fileperms($upload_dir)), -4) . "\n";

echo "\n=== Fix Commands for DigitalOcean ===\n";
echo "Run these commands on your DigitalOcean droplet:\n";
echo "1. sudo chown -R www-data:www-data " . dirname($upload_dir) . "\n";
echo "2. sudo chmod -R 755 " . dirname($upload_dir) . "\n";
echo "3. sudo chmod -R 777 " . $upload_dir . "\n";
echo "\nOr if using Apache:\n";
echo "1. sudo chown -R apache:apache " . dirname($upload_dir) . "\n";
echo "2. sudo chmod -R 755 " . dirname($upload_dir) . "\n";
echo "3. sudo chmod -R 777 " . $upload_dir . "\n";

echo "\n=== Alternative: Use absolute paths ===\n";
echo "Make sure your web server user can write to the uploads directory.\n";
echo "Check your web server configuration (Apache/Nginx) for the correct user.\n";
?>
