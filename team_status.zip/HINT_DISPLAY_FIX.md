# Hint Display Fix Documentation

## Problem
Hints were being displayed to ALL teams when ANY team solved a question, instead of only showing hints to the team that actually solved that specific question.

## Root Cause
The issue was in two API endpoints that were sending hint data to all teams regardless of their submission status:

1. **`get_team_progress.php`** - Line 131: `'hint' => $question['hint']`
2. **`get_question_detail.php`** - Line 108: `'hint' => $question['hint']`

Both endpoints were including the hint text in their responses for all teams, even if they hadn't solved the question.

## Solution
Updated both endpoints to conditionally include hints only for teams that have actually solved the question.

### Changes Made:

#### 1. `get_team_progress.php`
**Before:**
```php
'hint' => $question['hint'], // Always included
```

**After:**
```php
// Only show hint if team has solved this question
$hint_to_show = null;
if ($status === 'hint_unlocked' || $status === 'completed' || 
    ($submission_data && $submission_data['status'] === 'accepted')) {
    $hint_to_show = $question['hint'];
}

'hint' => $hint_to_show, // Only show hint if team solved it
```

#### 2. `get_question_detail.php`
**Before:**
```php
'hint' => $question['hint'], // Always included
```

**After:**
```php
// Only show hint if team has solved this question
$hint_to_show = null;
if ($overall_status === 'hint_unlocked' || $overall_status === 'completed' || 
    ($submission && $submission['status'] === 'accepted')) {
    $hint_to_show = $question['hint'];
}

'hint' => $hint_to_show, // Only show hint if team solved it
```

## How It Works Now

### Hint Display Logic:
- **`null`** - Team hasn't solved the question yet
- **`hint_text`** - Team has solved the question (status: `accepted`, `hint_unlocked`, or `completed`)

### Status Conditions for Hint Display:
1. **`hint_unlocked`** - Answer accepted, can submit photo
2. **`completed`** - Photo accepted, question fully solved
3. **`accepted`** - Answer accepted (from submission data)

### API Response Examples:

#### Team that hasn't solved Question 1:
```json
{
  "question": {
    "id": 1,
    "title": "Question 1",
    "hint": null,  // No hint shown
    "status": "available"
  }
}
```

#### Team that solved Question 1:
```json
{
  "question": {
    "id": 1,
    "title": "Question 1", 
    "hint": "Look for the red door",  // Hint shown
    "status": "hint_unlocked"
  }
}
```

## Verification

### Backend Verification:
- ✅ `get_hints.php` - Already working correctly (only shows hints for solved questions)
- ✅ `get_team_progress.php` - Fixed to conditionally show hints
- ✅ `get_question_detail.php` - Fixed to conditionally show hints

### Frontend Impact:
- Teams will now only see hints for questions they've actually solved
- No more "leaked" hints to other teams
- Proper competitive environment maintained

## Testing

To test the fix:

1. **Team A** solves Question 1 → Gets hint
2. **Team B** checks Question 1 → No hint shown (`hint: null`)
3. **Team B** solves Question 1 → Gets hint
4. **Team A** checks Question 1 → Still has hint (already solved)

## Security Impact

This fix improves the competitive integrity of the game by ensuring:
- ✅ Hints are only visible to teams that earned them
- ✅ No information leakage between teams
- ✅ Fair competition maintained
- ✅ Proper reward system for solving questions
