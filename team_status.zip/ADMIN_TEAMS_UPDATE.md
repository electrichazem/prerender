# Admin Teams Endpoint Update - Two-Phase Completion

## Overview
The `admin_get_teams.php` endpoint has been updated to reflect the new two-phase completion system. Now the "solved" count represents questions that are **fully completed with photos**, not just hint unlocked.

---

## 🔄 **What Changed**

### **Before (Old System):**
- `solved_count` = Questions with `status = 'accepted'` (hint unlocked)
- Progress percentage based on hint unlocked questions
- Only tracked answer submissions

### **After (New System):**
- `completed_count` = Questions with `photo_status = 'accepted'` (fully solved)
- `hint_unlocked_count` = Questions with `status = 'accepted'` (hint unlocked)
- Progress percentage based on **fully completed** questions
- Tracks both answer and photo submissions

---

## 📊 **New Response Structure**

### **Team Data:**
```json
{
  "success": true,
  "teams": [
    {
      "id": 1,
      "name": "Team Alpha",
      "code": "ALPHA123",
      "token": "abc123...",
      "created_at": "2023-10-20 10:00:00",
      "last_activity": "2023-10-22 12:30:45",
      "total_submissions": 8,
      "hint_unlocked_count": 3,        // NEW: Questions with hints unlocked
      "completed_count": 2,           // NEW: Questions fully completed (photos accepted)
      "pending_answer_count": 1,       // NEW: Answer submissions pending
      "pending_photo_count": 1,        // NEW: Photo submissions pending
      "progress_percentage": 20.0,     // Based on completed_count
      "is_online": true,
      "last_submission": "2023-10-22 12:30:45"
    }
  ],
  "total_questions": 10,
  "stats": {
    "total_teams": 5,
    "active_teams": 3,
    "average_progress": 15.2,
    "total_completed": 8,              // NEW: Total completed across all teams
    "total_hint_unlocked": 12          // NEW: Total hint unlocked across all teams
  }
}
```

---

## 🎯 **Key Changes**

### **1. Progress Calculation**
- **Old**: `progress_percentage = (solved_count / total_questions) * 100`
- **New**: `progress_percentage = (completed_count / total_questions) * 100`

### **2. Team Ranking**
- **Old**: Ordered by `solved_count DESC`
- **New**: Ordered by `completed_count DESC, hint_unlocked_count DESC`

### **3. Statistics**
- **Old**: Only basic team stats
- **New**: Added `total_completed` and `total_hint_unlocked` across all teams

---

## 📱 **Frontend Updates Needed**

### **1. Team List Display**
```javascript
// Update team progress display
const TeamCard = ({ team }) => {
  return (
    <div className="team-card">
      <h3>{team.name}</h3>
      <div className="progress-stats">
        <div className="stat completed">
          <span className="count">{team.completed_count}</span>
          <span className="label">Completed</span>
        </div>
        <div className="stat hint-unlocked">
          <span className="count">{team.hint_unlocked_count}</span>
          <span className="label">Hint Unlocked</span>
        </div>
        <div className="stat pending-answer">
          <span className="count">{team.pending_answer_count}</span>
          <span className="label">Answer Pending</span>
        </div>
        <div className="stat pending-photo">
          <span className="count">{team.pending_photo_count}</span>
          <span className="label">Photo Pending</span>
        </div>
      </div>
      <div className="progress-bar">
        <div 
          className="progress-fill" 
          style={{ width: `${team.progress_percentage}%` }}
        />
        <span className="progress-text">{team.progress_percentage}%</span>
      </div>
    </div>
  );
};
```

### **2. Team Statistics**
```javascript
// Update admin dashboard stats
const AdminStats = ({ stats }) => {
  return (
    <div className="admin-stats">
      <div className="stat-card">
        <h4>Total Teams</h4>
        <span className="count">{stats.total_teams}</span>
      </div>
      <div className="stat-card">
        <h4>Active Teams</h4>
        <span className="count">{stats.active_teams}</span>
      </div>
      <div className="stat-card">
        <h4>Questions Completed</h4>
        <span className="count">{stats.total_completed}</span>
      </div>
      <div className="stat-card">
        <h4>Hints Unlocked</h4>
        <span className="count">{stats.total_hint_unlocked}</span>
      </div>
      <div className="stat-card">
        <h4>Average Progress</h4>
        <span className="count">{stats.average_progress}%</span>
      </div>
    </div>
  );
};
```

---

## 🔧 **Migration Notes**

### **Frontend Changes Required:**
1. **Update team progress display** to show completed vs hint unlocked
2. **Modify progress bars** to reflect full completion
3. **Update team ranking** to prioritize completed questions
4. **Add new statistics** to admin dashboard

### **Backward Compatibility:**
- **Old field names** (`solved_count`, `pending_count`) removed
- **New field names** must be used in frontend
- **Progress calculation** now based on full completion

---

## 📊 **What the Numbers Mean**

### **Team Progress:**
- **`completed_count`**: Questions fully solved (photo accepted) - **This is the main "solved" count**
- **`hint_unlocked_count`**: Questions with hints unlocked (answer accepted)
- **`pending_answer_count`**: Answer submissions waiting for review
- **`pending_photo_count`**: Photo submissions waiting for review

### **Progress Percentage:**
- **Based on `completed_count`** - only fully solved questions count toward progress
- **More accurate representation** of actual completion
- **Reflects the competitive nature** of the two-phase system

---

## 🎯 **Admin Dashboard Updates**

### **Team Leaderboard:**
- **Primary ranking**: By `completed_count` (fully solved questions)
- **Secondary ranking**: By `hint_unlocked_count` (hints unlocked)
- **Clear distinction** between hint unlocked and fully completed

### **Statistics:**
- **Total completed**: Sum of all `completed_count` across teams
- **Total hint unlocked**: Sum of all `hint_unlocked_count` across teams
- **Average progress**: Based on full completion percentage

---

## ✅ **Summary**

**Yes, the admin teams page now updates correctly!** 

- **"Solved" count** = Questions completed with photos (`completed_count`)
- **Progress percentage** = Based on fully completed questions
- **Team ranking** = Prioritizes teams with most completed questions
- **Statistics** = Show total completed vs hint unlocked across all teams

The admin teams page now properly reflects the two-phase completion system where only questions with accepted photos are considered "solved"!
