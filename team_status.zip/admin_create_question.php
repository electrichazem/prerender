<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$title = isset($input['title']) ? trim($input['title']) : '';
$description_html = isset($input['description_html']) ? trim($input['description_html']) : '';
$hint = isset($input['hint']) ? trim($input['hint']) : '';
$display_order = isset($input['display_order']) ? intval($input['display_order']) : 0;

if (empty($title) || empty($description_html) || empty($hint) || $display_order <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "All fields are required and display order must be positive"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Check if display order already exists
    $order_check_query = "SELECT id FROM questions WHERE display_order = :display_order";
    $stmt = $db->prepare($order_check_query);
    $stmt->bindParam(':display_order', $display_order, PDO::PARAM_INT);
    $stmt->execute();
    
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(["error" => "Display order already exists"]);
        exit;
    }

    // Create new question
    $insert_query = "
        INSERT INTO questions (title, description_html, hint, display_order, is_active)
        VALUES (:title, :description_html, :hint, :display_order, 1)
    ";
    
    $stmt = $db->prepare($insert_query);
    $stmt->bindParam(':title', $title, PDO::PARAM_STR);
    $stmt->bindParam(':description_html', $description_html, PDO::PARAM_STR);
    $stmt->bindParam(':hint', $hint, PDO::PARAM_STR);
    $stmt->bindParam(':display_order', $display_order, PDO::PARAM_INT);
    $stmt->execute();

    $question_id = $db->lastInsertId();

    echo json_encode([
        "success" => true,
        "message" => "Question created successfully",
        "question_id" => $question_id
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>