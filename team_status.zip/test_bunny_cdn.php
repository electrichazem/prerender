<?php
// Bunny.net CDN Test Script
// Use this to test your existing storage zone configuration

include 'config.php';

echo "=== Bunny.net CDN Configuration Test ===\n\n";

// Test configuration loading
$config_file = __DIR__ . '/bunny_config.php';
if (!file_exists($config_file)) {
    echo "❌ bunny_config.php not found!\n";
    echo "Please create the configuration file first.\n";
    exit(1);
}

$config = include $config_file;
echo "✅ Configuration file loaded\n";

// Check if configuration values are set
$required_keys = ['storage_zone', 'api_key', 'cdn_url', 'upload_url'];
$missing_keys = [];

foreach ($required_keys as $key) {
    if (empty($config[$key]) || strpos($config[$key], 'your-') === 0) {
        $missing_keys[] = $key;
    }
}

if (!empty($missing_keys)) {
    echo "❌ Missing or placeholder configuration values:\n";
    foreach ($missing_keys as $key) {
        echo "   - $key\n";
    }
    echo "\nPlease update bunny_config.php with your actual credentials.\n";
    exit(1);
}

echo "✅ All configuration values are set\n";

// Test Bunny.net connection
echo "\nTesting Bunny.net connection...\n";

$bunny = new BunnyCDN();

// Create a small test file
$test_content = "This is a test file for Bunny.net CDN integration";
$test_filename = 'test_' . time() . '.txt';

echo "Uploading test file: $test_filename\n";

$upload_result = $bunny->uploadFile($test_content, $test_filename, 'test/');

if ($upload_result['success']) {
    echo "✅ Upload successful!\n";
    echo "   URL: " . $upload_result['url'] . "\n";
    
    // Test if the file is accessible
    echo "Testing file accessibility...\n";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $upload_result['url']);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code == 200) {
        echo "✅ File is accessible via CDN\n";
    } else {
        echo "⚠️  File upload succeeded but CDN access returned HTTP $http_code\n";
    }
    
    // Clean up test file
    echo "Cleaning up test file...\n";
    if ($bunny->deleteFile($test_filename, 'test/')) {
        echo "✅ Test file deleted successfully\n";
    } else {
        echo "⚠️  Could not delete test file (this is normal, it will expire)\n";
    }
    
} else {
    echo "❌ Upload failed: " . $upload_result['error'] . "\n";
    echo "\nTroubleshooting:\n";
    echo "1. Check your API key is correct\n";
    echo "2. Verify storage zone name matches exactly\n";
    echo "3. Ensure your Bunny.net account has sufficient credits\n";
    echo "4. Check if the storage zone is active\n";
}

echo "\n=== Test Complete ===\n";
echo "If all tests passed, your Bunny.net integration is ready!\n";
?>
