<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Get all teams with their progress (updated for two-phase completion)
    $teams_query = "
        SELECT 
            t.id,
            t.name,
            t.code,
            t.token,
            t.created_at,
            t.last_activity,
            COUNT(DISTINCT s.id) as total_submissions,
            COUNT(DISTINCT CASE WHEN s.status = 'accepted' THEN s.id END) as hint_unlocked_count,
            COUNT(DISTINCT CASE WHEN s.photo_status = 'accepted' THEN s.id END) as completed_count,
            COUNT(DISTINCT CASE WHEN s.status = 'pending' THEN s.id END) as pending_answer_count,
            COUNT(DISTINCT CASE WHEN s.photo_status = 'pending' THEN s.id END) as pending_photo_count,
            MAX(s.submitted_at) as last_submission
        FROM teams t
        LEFT JOIN submissions s ON t.id = s.team_id
        WHERE t.is_active = 1
        GROUP BY t.id, t.name, t.code, t.token, t.created_at, t.last_activity
        ORDER BY completed_count DESC, hint_unlocked_count DESC, last_activity DESC
    ";
    
    $stmt = $db->prepare($teams_query);
    $stmt->execute();
    $teams = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get total active questions count for progress calculation
    $questions_query = "SELECT COUNT(*) as total_questions FROM questions WHERE is_active = 1";
    $stmt = $db->prepare($questions_query);
    $stmt->execute();
    $questions_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $total_questions = (int)$questions_result['total_questions'];

    // Calculate progress for each team (updated for two-phase completion)
    foreach ($teams as &$team) {
        $team['hint_unlocked_count'] = (int)$team['hint_unlocked_count'];
        $team['completed_count'] = (int)$team['completed_count'];
        $team['pending_answer_count'] = (int)$team['pending_answer_count'];
        $team['pending_photo_count'] = (int)$team['pending_photo_count'];
        $team['total_submissions'] = (int)$team['total_submissions'];
        
        // Progress percentage based on completed questions (photos accepted)
        $team['progress_percentage'] = $total_questions > 0 ? 
            round(($team['completed_count'] / $total_questions) * 100, 1) : 0;
            
        $team['is_online'] = $team['last_activity'] && 
            strtotime($team['last_activity']) > (time() - 300); // 5 minutes
    }

    echo json_encode([
        "success" => true,
        "teams" => $teams,
        "total_questions" => $total_questions,
        "stats" => [
            "total_teams" => count($teams),
            "active_teams" => count(array_filter($teams, function($team) { 
                return $team['is_online']; 
            })),
            "average_progress" => count($teams) > 0 ? 
                round(array_sum(array_column($teams, 'progress_percentage')) / count($teams), 1) : 0,
            "total_completed" => array_sum(array_column($teams, 'completed_count')),
            "total_hint_unlocked" => array_sum(array_column($teams, 'hint_unlocked_count'))
        ]
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>