<?php
// Bunny.net CDN Configuration Template
// Copy this file to bunny_config.php and update with your actual credentials

return [
    'storage_zone' => 'your-storage-zone-name',        // Your Bunny.net storage zone name
    'api_key' => 'your-api-key-here',                  // Your Bunny.net API key
    'cdn_url' => 'https://your-storage-zone.b-cdn.net', // Your CDN URL
    'upload_url' => 'https://storage.bunnycdn.com/your-storage-zone', // Upload URL
    'upload_path' => 'uploads/photos/',                // Path within storage zone
    'max_file_size' => 10 * 1024 * 1024,              // 10MB max file size
    'allowed_types' => ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
];

// Instructions:
// 1. Go to your Bunny.net dashboard
// 2. Create a storage zone or use existing one
// 3. Get your API key from the storage zone settings
// 4. Update the values above with your actual credentials
// 5. Test the upload functionality
?>
