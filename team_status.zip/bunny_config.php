<?php
// Bunny.net CDN Configuration - Using existing storage zone from old project
// Update these values with your existing Bunny.net credentials

return [
    // Using the same storage zone from your old project
    'storage_zone' => 'robo',                     // Same storage zone as old project
    'api_key' => 'a185a30e-fa7f-4f6a-a951fad46f39-f552-403b',                        // You need to provide your API key
    'cdn_url' => 'https://robo.b-cdn.net',       // Same CDN URL as old project
    'upload_url' => 'https://storage.bunnycdn.com/robo0', // Same upload URL as old project
    'upload_path' => 'robo/photos/',                         // New path for robotics workshop photos
];

// Instructions:
// ✅ Storage zone found: 'edu-books-images' (from your old project)
// ✅ CDN URL found: 'https://edu-books-images.b-cdn.net' (from your old project)
// ✅ Upload URL found: 'https://storage.bunnycdn.com/edu-books-images' (from your old project)
// 
// You only need to:
// 1. Get your API key from Bunny.net dashboard for 'edu-books-images' storage zone
// 2. Replace 'your-api-key-here' with your actual API key
// 3. Test the photo upload functionality

// Your photos will be stored at:
// https://edu-books-images.b-cdn.net/robo/photos/team_1_question_1_1640995200.jpg
?>
