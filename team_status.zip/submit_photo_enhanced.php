<?php
// Enhanced Photo Upload Handler
// This version handles various server configurations and provides better error reporting

include 'config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$question_id = isset($input['question_id']) ? intval($input['question_id']) : 0;
$photo_data = isset($input['photo_data']) ? $input['photo_data'] : '';

if ($question_id <= 0 || empty($photo_data)) {
    http_response_code(400);
    echo json_encode(["error" => "Question ID and photo data are required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token and get team ID
    $team_query = "SELECT id FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Check if question exists and is active
    $question_query = "SELECT id FROM questions WHERE id = :question_id AND is_active = 1";
    $stmt = $db->prepare($question_query);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $question = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$question) {
        http_response_code(404);
        echo json_encode(["error" => "Question not found or inactive"]);
        exit;
    }

    // Check if team has an accepted submission for this question
    $submission_query = "SELECT id, status FROM submissions 
                        WHERE team_id = :team_id AND question_id = :question_id AND status = 'accepted'";
    $stmt = $db->prepare($submission_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $submission = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$submission) {
        http_response_code(403);
        echo json_encode(["error" => "Hint not unlocked yet. Answer must be accepted first."]);
        exit;
    }

    // Process photo data
    if (strpos($photo_data, 'data:image/') === 0) {
        $photo_data = substr($photo_data, strpos($photo_data, ',') + 1);
    }
    
    $decoded_photo = base64_decode($photo_data);
    if ($decoded_photo === false) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid photo data"]);
        exit;
    }

    // Generate unique filename
    $filename = 'team_' . $team_id . '_question_' . $question_id . '_' . time() . '.jpg';
    
    // Try multiple upload locations
    $upload_locations = [
        __DIR__ . '/uploads/photos/',
        $_SERVER['DOCUMENT_ROOT'] . '/uploads/photos/',
        '/var/www/html/uploads/photos/',
        '/home/ubuntu/uploads/photos/'
    ];
    
    $upload_success = false;
    $final_filepath = '';
    
    foreach ($upload_locations as $upload_dir) {
        echo "Trying upload location: $upload_dir\n";
        
        // Create directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0755, true)) {
                continue; // Try next location
            }
        }
        
        // Check if directory is writable
        if (!is_writable($upload_dir)) {
            continue; // Try next location
        }
        
        $filepath = $upload_dir . $filename;
        
        // Try to save the file
        $bytes_written = file_put_contents($filepath, $decoded_photo);
        if ($bytes_written !== false) {
            $upload_success = true;
            $final_filepath = $filepath;
            break;
        }
    }
    
    if (!$upload_success) {
        http_response_code(500);
        echo json_encode([
            "error" => "Failed to save photo on all attempted locations",
            "debug" => [
                "attempted_locations" => $upload_locations,
                "current_user" => get_current_user(),
                "php_user" => getenv('USER'),
                "web_server_user" => getenv('APACHE_RUN_USER') ?: getenv('NGINX_USER') ?: 'unknown'
            ]
        ]);
        exit;
    }

    // Update submission with photo information
    $update_query = "UPDATE submissions 
                    SET photo_filename = :filename, 
                        photo_submitted_at = NOW(), 
                        photo_status = 'pending'
                    WHERE id = :submission_id";
    
    $stmt = $db->prepare($update_query);
    $stmt->bindParam(':filename', $filename, PDO::PARAM_STR);
    $stmt->bindParam(':submission_id', $submission['id'], PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "Photo submitted successfully and pending review",
        "filename" => $filename,
        "filepath" => $final_filepath,
        "submission_id" => $submission['id']
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>
