<?php
include 'config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

$question_id = isset($_GET['question_id']) ? intval($_GET['question_id']) : 0;

if ($question_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Valid question ID is required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token
    $team_query = "SELECT id FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Get question details and check if globally completed
    $question_query = "
        SELECT q.id, q.title, q.description_html, q.hint, q.display_order,
               CASE WHEN EXISTS(
                   SELECT 1 FROM submissions s 
                   WHERE s.question_id = q.id AND s.photo_status = 'accepted'
               ) THEN 1 ELSE 0 END as is_globally_completed
        FROM questions q 
        WHERE q.id = :question_id AND q.is_active = 1";
    $stmt = $db->prepare($question_query);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $question = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$question) {
        http_response_code(404);
        echo json_encode(["error" => "Question not found or inactive"]);
        exit;
    }

    $is_globally_completed = (bool)$question['is_globally_completed'];

    // Get submission status for this question
    $submission_query = "SELECT status, submitted_answer, admin_notes, photo_status, photo_filename, photo_admin_notes 
                        FROM submissions 
                        WHERE team_id = :team_id AND question_id = :question_id";
    $stmt = $db->prepare($submission_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $submission = $stmt->fetch(PDO::FETCH_ASSOC);

    // Determine overall status and available actions
    $status = $submission ? $submission['status'] : 'available';
    $photo_status = $submission ? $submission['photo_status'] : null;
    
    $can_submit_answer = false;
    $can_submit_photo = false;
    $overall_status = $status;
    
    // Global completion takes precedence
    if ($is_globally_completed) {
        $overall_status = 'globally_completed';
        $can_submit_answer = false;
        $can_submit_photo = false;
    } else if ($photo_status === 'accepted') {
        $overall_status = 'completed';
    } else if ($status === 'accepted' && ($photo_status === 'pending' || $photo_status === 'rejected' || $photo_status === null)) {
        $overall_status = 'hint_unlocked';
        $can_submit_photo = true;
    } else if ($status === 'available' || $status === 'rejected') {
        $can_submit_answer = true;
    }

    // Only show hint if team has solved this question
    $hint_to_show = null;
    if ($overall_status === 'hint_unlocked' || $overall_status === 'completed' || 
        ($submission && $submission['status'] === 'accepted')) {
        $hint_to_show = $question['hint'];
    }

    echo json_encode([
        "success" => true,
        "question" => [
            'id' => $question['id'],
            'title' => $question['title'],
            'description_html' => $question['description_html'],
            'hint' => $hint_to_show, // Only show hint if team solved it
            'status' => $overall_status,
            'can_submit_answer' => $can_submit_answer,
            'can_submit_photo' => $can_submit_photo,
            'submitted_answer' => $submission ? $submission['submitted_answer'] : null,
            'admin_notes' => $submission ? $submission['admin_notes'] : null,
            'photo_filename' => $submission ? $submission['photo_filename'] : null,
            'photo_admin_notes' => $submission ? $submission['photo_admin_notes'] : null,
            'answer_status' => $status,
            'photo_status' => $photo_status,
            'is_globally_completed' => $is_globally_completed
        ]
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>