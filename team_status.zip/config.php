<?php
// CORS headers to allow all origins
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow all origins
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Allow-Credentials: false'); // Set to false when using *

// Handle preflight OPTIONS request

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Bunny.net CDN Configuration
class BunnyCDN {
    private $storage_zone;
    private $api_key;
    private $cdn_url;
    private $upload_url;
    private $upload_path;
    
    public function __construct() {
        // Load configuration from bunny_config.php if it exists
        $config_file = __DIR__ . '/bunny_config.php';
        if (file_exists($config_file)) {
            $config = include $config_file;
            $this->storage_zone = $config['storage_zone'];
            $this->api_key = $config['api_key'];
            $this->cdn_url = $config['cdn_url'];
            $this->upload_url = $config['upload_url'];
            $this->upload_path = $config['upload_path'] ?? 'uploads/photos/';
        } else {
            // Default configuration (replace with your actual values)
            $this->storage_zone = 'your-storage-zone';
            $this->api_key = 'your-api-key';
            $this->cdn_url = 'https://your-storage-zone.b-cdn.net';
            $this->upload_url = 'https://storage.bunnycdn.com/your-storage-zone';
            $this->upload_path = 'uploads/photos/';
        }
    }
    
    public function uploadFile($file_content, $filename, $path = 'uploads/photos/') {
        $url = $this->upload_url . '/' . $path . $filename;
        
        $headers = [
            'AccessKey: ' . $this->api_key,
            'Content-Type: application/octet-stream'
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PUT, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $file_content);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['success' => false, 'error' => 'CURL Error: ' . $error];
        }
        
        if ($http_code >= 200 && $http_code < 300) {
            return [
                'success' => true, 
                'url' => $this->cdn_url . '/' . $path . $filename,
                'filename' => $filename
            ];
        } else {
            return ['success' => false, 'error' => 'Upload failed with HTTP code: ' . $http_code];
        }
    }
    
    public function deleteFile($filename, $path = 'uploads/photos/') {
        $url = $this->upload_url . '/' . $path . $filename;
        
        $headers = [
            'AccessKey: ' . $this->api_key
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return $http_code >= 200 && $http_code < 300;
    }
}

class Database {
    private $host = 'localhost';
    private $db_name = 'robotics_hunt';
    private $username = 'root';
    private $password = '';
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            echo json_encode(["error" => "Database connection failed: " . $exception->getMessage()]);
            exit;
        }
        return $this->conn;
    }
}
?>