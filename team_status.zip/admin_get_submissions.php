<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Get filter parameters
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = 20;
    $offset = ($page - 1) * $limit;

    // Build query with filters
    $where_conditions = ["1=1"];
    $params = [];

    if ($status !== 'all') {
        $where_conditions[] = "s.status = :status";
        $params[':status'] = $status;
    }

    $where_clause = implode(" AND ", $where_conditions);

    // Get submissions with photo information
    $submissions_query = "
        SELECT s.id, s.submitted_answer, s.status, s.submitted_at, s.admin_notes,
               s.photo_filename, s.photo_status, s.photo_submitted_at, s.photo_admin_notes,
               t.name as team_name, t.id as team_id,
               q.title as question_title, q.id as question_id, q.hint as question_hint
        FROM submissions s
        JOIN teams t ON s.team_id = t.id
        JOIN questions q ON s.question_id = q.id
        WHERE $where_clause
        ORDER BY s.submitted_at DESC
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $db->prepare($submissions_query);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get total count for pagination
    $count_query = "
        SELECT COUNT(*) as total
        FROM submissions s
        WHERE $where_clause
    ";
    $stmt = $db->prepare($count_query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    $count_result = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "submissions" => $submissions,
        "pagination" => [
            "current_page" => $page,
            "total_pages" => ceil($count_result['total'] / $limit),
            "total_submissions" => (int)$count_result['total'],
            "limit" => $limit
        ]
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>