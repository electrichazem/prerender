# Bunny.net CDN Integration Documentation

## Overview
The photo upload system has been updated to use Bunny.net CDN instead of local file storage. This provides better performance, reliability, and scalability for image uploads.

## Key Features

✅ **No Database Changes** - Uses existing `photo_filename` field to store CDN URLs
✅ **Backward Compatibility** - Still works with existing local photos
✅ **Automatic Detection** - Detects CDN URLs vs local filenames automatically
✅ **Error Handling** - Comprehensive error handling for upload failures
✅ **Configuration** - Easy configuration through `bunny_config.php`

## Setup Instructions (Using Existing Storage Zone)

### 1. Get Credentials from Old Project
1. Find your existing Bunny.net storage zone name
2. Get your existing API key
3. Note your existing CDN URL
4. Copy the upload path structure (if any)

### 2. Configure Application
1. Edit `bunny_config.php`
2. Update the configuration values with your existing credentials:

```php
return [
    'storage_zone' => 'your-existing-storage-zone',     // Your existing storage zone name
    'api_key' => 'your-existing-api-key',               // Your existing API key
    'cdn_url' => 'https://your-existing-storage-zone.b-cdn.net', // Your existing CDN URL
    'upload_url' => 'https://storage.bunnycdn.com/your-existing-storage-zone', // Your existing upload URL
    'upload_path' => 'uploads/photos/',                 // Path within storage zone
];
```

### 3. Test Configuration
1. Run the test script: `php test_bunny_cdn.php`
2. Verify upload and CDN access work
3. Check that files are accessible via your existing CDN URL

## How It Works

### Photo Upload Process:
1. **Team submits photo** → `submit_photo.php`
2. **Decode base64** → Convert to binary data
3. **Upload to Bunny.net** → Store in CDN
4. **Get CDN URL** → Receive public URL
5. **Store URL in database** → Save in `photo_filename` field
6. **Return success** → Team gets confirmation

### Photo Retrieval Process:
1. **Admin requests photo** → `admin_get_photo.php`
2. **Check photo_filename** → Detect if it's CDN URL or local file
3. **If CDN URL** → Return URL directly
4. **If local file** → Fallback to local file system
5. **Return photo data** → Admin gets photo

## Database Schema (No Changes Required)

The system uses the existing `submissions` table:

```sql
-- Existing table structure (no changes needed)
submissions.photo_filename VARCHAR(255) -- Now stores CDN URLs
```

### Data Storage Examples:

**CDN URL (new photos):**
```
photo_filename = "https://robotics-hunt-photos.b-cdn.net/uploads/photos/team_1_question_1_1640995200.jpg"
```

**Local filename (existing photos):**
```
photo_filename = "team_1_question_1_1640995200.jpg"
```

## API Changes

### submit_photo.php Response:
```json
{
    "success": true,
    "message": "Photo submitted successfully and pending review",
    "filename": "team_1_question_1_1640995200.jpg",
    "photo_url": "https://robotics-hunt-photos.b-cdn.net/uploads/photos/team_1_question_1_1640995200.jpg",
    "submission_id": 123
}
```

### admin_get_photo.php Response:
```json
{
    "success": true,
    "submission": {
        "id": 123,
        "team_name": "Team Alpha",
        "question_title": "Question 1",
        "photo_status": "pending",
        "photo_data": "https://robotics-hunt-photos.b-cdn.net/uploads/photos/team_1_question_1_1640995200.jpg",
        "filename": "https://robotics-hunt-photos.b-cdn.net/uploads/photos/team_1_question_1_1640995200.jpg"
    }
}
```

## Benefits

### Performance:
- ✅ **Global CDN** - Photos served from edge locations worldwide
- ✅ **Fast uploads** - Direct upload to Bunny.net servers
- ✅ **No server load** - Images don't consume your server bandwidth

### Reliability:
- ✅ **99.9% uptime** - Bunny.net's reliable infrastructure
- ✅ **Automatic backups** - Built-in redundancy
- ✅ **Scalable** - Handles traffic spikes automatically

### Cost:
- ✅ **Pay per use** - Only pay for what you use
- ✅ **Free tier** - 1GB storage + 1TB bandwidth free
- ✅ **Competitive pricing** - Much cheaper than AWS S3

## Testing

### Test Upload:
1. Submit a photo through the team interface
2. Check the response for `photo_url`
3. Verify the URL works in browser
4. Check admin interface displays photo correctly

### Test Backward Compatibility:
1. Existing local photos should still work
2. Admin interface should detect and handle both types
3. No errors when viewing old submissions

## Troubleshooting

### Common Issues:

**Upload fails:**
- Check API key is correct
- Verify storage zone name matches
- Ensure Bunny.net account has sufficient credits

**Photos not displaying:**
- Check CDN URL is accessible
- Verify upload path is correct
- Test URL in browser directly

**Configuration errors:**
- Ensure `bunny_config.php` exists
- Check all configuration values are set
- Verify file permissions

### Debug Mode:
Add this to your config for detailed error messages:
```php
// In bunny_config.php
'debug' => true
```

## Migration from Local Storage

If you have existing local photos, they will continue to work. The system automatically detects:
- **CDN URLs** (start with `http`) → Serve directly
- **Local files** (don't start with `http`) → Serve from local storage

No migration is required - the system handles both types seamlessly.
