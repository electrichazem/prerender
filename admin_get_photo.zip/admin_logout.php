<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Clear admin token
    $logout_query = "UPDATE admin_users SET admin_token = NULL WHERE admin_token = :token";
    $stmt = $db->prepare($logout_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "Admin logged out successfully"
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>