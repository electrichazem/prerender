-- Teams Insert Script
-- This script inserts all teams for the robotics workshop hunt

-- Clear existing teams (optional - remove if you want to keep existing data)
-- DELETE FROM teams;

-- Insert all teams with actual team names and email addresses as team codes
INSERT INTO teams (name, code, is_active, created_at) VALUES

-- Team 1
('</OMO>', 'meromaro2010hamodi@gmail.com', 1, NOW()),

-- Team 2
('ZOM', 'ahmedzagloul101@gmail.com', 1, NOW()),

-- Team 3
('mahmoud gouda', 'mahmoudgouda737@gmail.com', 1, NOW()),

-- Team 4
('Dark knights', 'YoussefHossam1230@gmail.com', 1, NOW()),

-- Team 5
('ربطة المعلم', 'andrewraafat834@gmail.com', 1, NOW()),

-- Team 6
('zoz team', 'waleedziad040@gmail.com', 1, NOW()),

-- Team 7
('Kafr meet sensor', 'davedmaher7@gmail.com', 1, NOW()),

-- Team 8
('TRIPLE A', 'abdelrazkforman966@gmail.com', 1, NOW()),

-- Team 9
('3Ys', 'youssefmoham655@gmail.com', 1, NOW()),

-- Team 10 (Note: This team has two emails listed, using the first one)
('28 Bots', 'hamzaawad8899@gmail.com', 1, NOW()),

-- Team 11
('Zombies Team', 'nadahamed043@gmail.com', 1, NOW()),

-- Team 12
('Breaking bad', 'mohandnazeeh1@gmail.com', 1, NOW()),

-- Team 13
('Aho', 'youssefosso63@gmail.com', 1, NOW()),

-- Team 14
('خليها على الله', 'tefashaat@gmail.com', 1, NOW()),

-- Team 15
('MechaMinds', 'ahmedramadanelsayed@outlook.com', 1, NOW()),

-- Team 16
('Robo guys', 'justjohnrommil@gmail.com', 1, NOW()),

-- Team 17
('Virmethor', 'mazenmohammed2610@gmail.com', 1, NOW()),

-- Team 18
('Room 207', 'omarhany0510@gmail.com', 1, NOW()),

-- Team 19
('Proficients', 'youssifahmed104@gmail.com', 1, NOW()),

-- Team 20
('Falcons', 'abdohoba321@gmail.com', 1, NOW()),

-- Team 21
('Team A+', 'adhamfaied14@gmail.com', 1, NOW()),

-- Team 22
('فريق خليها علي الله', 'omar1221223@gmail.com', 1, NOW()),

-- Team 23
('Wenners', 'youssif.abdelaty2010@gmail.com', 1, NOW()),

-- Team 24
('FAX', 'mohfekry26@gmail.com', 1, NOW()),

-- Team 25
('Ora Masters', 'vegomedo4@gmail.com', 1, NOW()),

-- Team 26
('AlBaraa Mohammad Salama', 'albaraamohammed.personal@gmail.com', 1, NOW()),

-- Team 27
('the peak', 'anmedtaha.1@gmail.com', 1, NOW()),

-- Team 28
('The eagles', 'marwansakr232@gmail.com', 1, NOW()),

-- Team 29
('Marawan', 'marawan.ayman2010@gmail.com', 1, NOW());

-- Verify the insert
SELECT COUNT(*) as total_teams FROM teams WHERE is_active = 1;

-- Show all inserted teams
SELECT id, name, code, is_active, created_at FROM teams ORDER BY id;

-- Note: Team 10 has two emails listed:
-- Primary: hamzaawad8899@gmail.com
-- Secondary: yousef.mohamed.safwat1015@gmail.com
-- You may want to create a separate team for the second email if needed
