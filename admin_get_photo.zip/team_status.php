<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$team_code = isset($input['team_code']) ? trim($input['team_code']) : '';

if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Team code is required"]);
    exit;
}

// Sanitize team code (alphanumeric only)
$team_code = preg_replace('/[^a-zA-Z0-9]/', '', $team_code);
if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid team code format"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Check if team exists
    $check_team_query = "SELECT id, name, token, last_activity FROM teams WHERE code = :code AND is_active = 1";
    $stmt = $db->prepare($check_team_query);
    $stmt->bindParam(':code', $team_code, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(404);
        echo json_encode(["error" => "Team not found or inactive"]);
        exit;
    }

    $has_token = !empty($team['token']);
    $status = $has_token ? 'active' : 'inactive';

    echo json_encode([
        "success" => true,
        "team" => [
            "id" => $team['id'],
            "name" => $team['name'],
            "code" => $team_code,
            "status" => $status,
            "has_token" => $has_token,
            "last_activity" => $team['last_activity']
        ],
        "message" => $has_token ? "Team is active with token" : "Team is inactive (no token)"
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>
