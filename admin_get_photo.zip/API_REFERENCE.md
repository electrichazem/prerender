# API Reference - Two-Phase Completion System

## Authentication
All endpoints require Bearer token authentication:
```
Authorization: Bearer <token>
```

---

## 📱 Student Endpoints

### 1. Submit Photo
**POST** `/submit_photo.php`

Submit a photo after hint is unlocked.

**Request:**
```json
{
  "question_id": 123,
  "photo_data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ..."
}
```

**Response (Success):**
```json
{
  "success": true,
  "message": "Photo submitted successfully and pending review",
  "filename": "team_5_question_123_1698123456.jpg",
  "submission_id": 456
}
```

**Error Responses:**
- `401`: Invalid or expired token
- `403`: Hint not unlocked yet (answer must be accepted first)
- `404`: Question not found or inactive
- `409`: Photo already submitted/accepted
- `400`: Invalid photo data or missing parameters

---

### 2. Get Team Progress (Updated)
**GET** `/get_team_progress.php`

Get team's progress with new two-phase statuses.

**Query Parameters:**
- `last_check` (optional): Timestamp for new hints count

**Response:**
```json
{
  "success": true,
  "team_name": "Team Alpha",
  "progress": {
    "total_questions": 10,
    "completed": 3,
    "hint_unlocked": 2,
    "pending_answer": 1,
    "pending_photo": 1,
    "available": 3
  },
  "questions": [
    {
      "id": 123,
      "title": "Robot Assembly Challenge",
      "description_html": "<p>Find the red component...</p>",
      "hint": "Look near the main circuit board",
      "display_order": 1,
      "status": "hint_unlocked",
      "can_submit_answer": false,
      "can_submit_photo": true,
      "answer_status": "accepted",
      "photo_status": null
    }
  ],
  "unlocked_hints": [
    {
      "question_id": 123,
      "title": "Robot Assembly Challenge",
      "hint": "Look near the main circuit board",
      "submitted_at": "2023-10-22 12:00:00",
      "photo_status": null
    }
  ],
  "new_hints_count": 1,
  "last_updated": "2023-10-22 12:30:45"
}
```

---

### 3. Get Question Detail (Updated)
**GET** `/get_question_detail.php?question_id=123`

Get detailed information about a specific question.

**Response:**
```json
{
  "success": true,
  "question": {
    "id": 123,
    "title": "Robot Assembly Challenge",
    "description_html": "<p>Find the red component...</p>",
    "hint": "Look near the main circuit board",
    "status": "hint_unlocked",
    "can_submit_answer": false,
    "can_submit_photo": true,
    "submitted_answer": "The red resistor",
    "admin_notes": "Correct!",
    "photo_filename": "team_5_question_123_1698123456.jpg",
    "photo_admin_notes": null,
    "answer_status": "accepted",
    "photo_status": "pending"
  }
}
```

---

## 🔧 Admin Endpoints

### 1. Review Submission (Updated)
**POST** `/admin_review_submission.php`

Review either answer or photo submissions.

**Request:**
```json
{
  "submission_id": 456,
  "action": "accept",
  "admin_notes": "Great photo! Component clearly visible.",
  "review_type": "photo"
}
```

**Parameters:**
- `submission_id`: ID of the submission to review
- `action`: "accept" or "reject"
- `admin_notes`: Optional notes from admin
- `review_type`: "answer" or "photo"

**Response (Answer Review):**
```json
{
  "success": true,
  "message": "Answer submission accepted successfully",
  "submission_id": 456,
  "new_status": "accepted",
  "review_type": "answer"
}
```

**Response (Photo Review):**
```json
{
  "success": true,
  "message": "Photo submission accepted successfully",
  "submission_id": 456,
  "new_photo_status": "accepted",
  "review_type": "photo",
  "question_completed": true
}
```

---

### 2. Get Photo
**GET** `/admin_get_photo.php?submission_id=456`

Retrieve a submitted photo for admin review.

**Response:**
```json
{
  "success": true,
  "submission": {
    "id": 456,
    "team_name": "Team Alpha",
    "question_title": "Robot Assembly Challenge",
    "photo_status": "pending",
    "photo_submitted_at": "2023-10-22 12:30:45",
    "photo_data": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQ...",
    "filename": "team_5_question_123_1698123456.jpg"
  }
}
```

---

### 3. Get Submissions (Updated)
**GET** `/admin_get_submissions.php`

Get all submissions with photo information.

**Query Parameters:**
- `status`: Filter by status ("all", "pending", "accepted", "rejected")
- `page`: Page number for pagination

**Response:**
```json
{
  "success": true,
  "submissions": [
    {
      "id": 456,
      "submitted_answer": "The red resistor",
      "status": "accepted",
      "submitted_at": "2023-10-22 12:00:00",
      "admin_notes": "Correct!",
      "photo_filename": "team_5_question_123_1698123456.jpg",
      "photo_status": "pending",
      "photo_submitted_at": "2023-10-22 12:30:45",
      "photo_admin_notes": null,
      "team_name": "Team Alpha",
      "team_id": 5,
      "question_title": "Robot Assembly Challenge",
      "question_id": 123,
      "question_hint": "Look near the main circuit board"
    }
  ],
  "pagination": {
    "current_page": 1,
    "total_pages": 3,
    "total_submissions": 45,
    "limit": 20
  }
}
```

---

### 4. Get Questions (Updated)
**GET** `/admin_get_questions.php`

Get all questions with photo submission statistics.

**Response:**
```json
{
  "success": true,
  "questions": [
    {
      "id": 123,
      "title": "Robot Assembly Challenge",
      "description_html": "<p>Find the red component...</p>",
      "hint": "Look near the main circuit board",
      "display_order": 1,
      "is_active": true,
      "created_at": "2023-10-20 10:00:00",
      "total_submissions": 5,
      "accepted_count": 3,
      "pending_count": 1,
      "completed_count": 2,
      "photo_pending_count": 1
    }
  ]
}
```

---

## 📊 Status Reference

### Question Statuses
- `available`: Can submit answer
- `pending_answer`: Answer submitted, waiting review
- `hint_unlocked`: Answer accepted, can submit photo
- `pending_photo`: Photo submitted, waiting review
- `completed`: Photo accepted, question fully solved
- `globally_completed`: Question completed by another team (locked for all other teams)
- `rejected`: Answer/photo rejected, can resubmit

### Submission Statuses
- `pending`: Waiting for admin review
- `accepted`: Approved by admin
- `rejected`: Rejected by admin

### Photo Statuses
- `pending`: Photo submitted, waiting review
- `accepted`: Photo approved, question completed
- `rejected`: Photo rejected, can resubmit

---

## 🔄 Complete Flow Example

### Student Journey:
1. **Submit Answer**: `POST /submit_answer.php`
2. **Check Status**: `GET /get_team_progress.php` → status: "pending_answer"
3. **Admin Reviews**: Admin uses `POST /admin_review_submission.php` with `review_type: "answer"`
4. **Hint Unlocked**: `GET /get_team_progress.php` → status: "hint_unlocked"
5. **Submit Photo**: `POST /submit_photo.php`
6. **Check Status**: `GET /get_team_progress.php` → status: "pending_photo"
7. **Admin Reviews Photo**: Admin uses `POST /admin_review_submission.php` with `review_type: "photo"`
8. **Question Completed**: `GET /get_team_progress.php` → status: "completed"

### Admin Journey:
1. **View Submissions**: `GET /admin_get_submissions.php`
2. **Review Answer**: `POST /admin_review_submission.php` with `review_type: "answer"`
3. **View Photo**: `GET /admin_get_photo.php?submission_id=456`
4. **Review Photo**: `POST /admin_review_submission.php` with `review_type: "photo"`

---

## 🚨 Error Handling

### Common Error Codes:
- `400`: Bad Request - Invalid parameters
- `401`: Unauthorized - Invalid/missing token
- `403`: Forbidden - Action not allowed (e.g., hint not unlocked)
- `404`: Not Found - Resource doesn't exist
- `409`: Conflict - Duplicate submission
- `500`: Server Error - Database or server issue

### Error Response Format:
```json
{
  "error": "Error message description"
}
```

---

## 📁 File Structure

```
uploads/
└── photos/
    ├── team_1_question_123_1698123456.jpg
    ├── team_2_question_124_1698123457.jpg
    └── ...
```

Photo files are named: `team_{team_id}_question_{question_id}_{timestamp}.jpg`

---

## 🔐 Security Notes

1. **File Upload**: Photos are validated and stored securely
2. **Authentication**: All endpoints require valid tokens
3. **Authorization**: Teams can only access their own submissions
4. **File Access**: Photos are only accessible via admin endpoints
5. **Input Validation**: All inputs are sanitized and validated

---

## 📱 Mobile Considerations

1. **Camera Access**: Use `capture="environment"` for back camera
2. **File Size**: Consider image compression for mobile uploads
3. **Network**: Handle upload failures gracefully
4. **Storage**: Photos are stored server-side, not locally

This API reference should help frontend developers implement the new two-phase completion system effectively!
