-- Robotics Hunt Questions Insert Script
-- This script inserts all 37 questions for the robotics workshop hunt with randomized order

-- Clear existing questions (optional - remove if you want to keep existing data)
-- DELETE FROM questions;

-- Insert all 37 questions with simple titles and randomized order
INSERT INTO questions (title, description_html, hint, display_order, is_active, created_at) VALUES

-- Randomized order to mix different component types
('Question 1', '<p>I\'m the skeleton of your RC car (every motor, wire, and wheel depends on me) to stay in place. What am I?</p>', 'https://edu-books-images.b-cdn.net/robo/1.png', 1, 1, NOW()),

('Question 2', '<p>They don\'t move, they don\'t talk, but they make the school look cool. How many palm trees are standing proudly around our campus?</p>', 'https://edu-books-images.b-cdn.net/robo/20.png', 2, 1, NOW()),

('Question 3', '<p>I turn electrical energy into motion; I\'m the real powerhouse behind your car\'s movement. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/3.png', 3, 1, NOW()),

('Question 4', '<p>I\'m full of holes, but that\'s my job! I hold your circuits together without any glue.</p>', 'https://edu-books-images.b-cdn.net/robo/7.png', 4, 1, NOW()),

('Question 5', '<p>Give me voltage, and I\'ll give you rotation. No power, no spin. What am I?</p>', 'https://edu-books-images.b-cdn.net/robo/4.png', 5, 1, NOW()),

('Question 6', '<p>You\'ve been walking here all week, but do you really know where you are? What\'s the full name of our school?</p>', 'https://edu-books-images.b-cdn.net/robo/22.png', 6, 1, NOW()),

('Question 7', '<p>I\'m tiny, but keep your big ideas in place. Without me, your frame\'s a flop.</p>', 'https://edu-books-images.b-cdn.net/robo/9.png', 7, 1, NOW()),

('Question 8', '<p>I\'m small but strong. My job is to make your car go. What am I?</p>', 'https://edu-books-images.b-cdn.net/robo/5.png', 8, 1, NOW()),

('Question 9', '<p>Where experiments, explosions (safe ones!), and genius ideas happen, how many labs do we have in our school?</p>', 'https://edu-books-images.b-cdn.net/robo/21.png', 9, 1, NOW()),

('Question 10', '<p>You poke me hundreds of times, and I never complain about it. I\'m your electronics playground!</p>', 'https://edu-books-images.b-cdn.net/robo/8.png', 10, 1, NOW()),

('Question 11', '<p>I let your motors go forward and backward, I\'m basically the car\'s brain for direction!</p>', 'https://edu-books-images.b-cdn.net/robo/10.png', 11, 1, NOW()),

('Question 12', '<p>I\'m basically the heart that beats when current flows, turning stillness into speed. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/6.png', 12, 1, NOW()),

('Question 13', '<p>I may be small, but I run the show. I\'m like your teacher\'s brain, just with more pins.</p>', 'https://edu-books-images.b-cdn.net/robo/11.png', 13, 1, NOW()),

('Question 14', '<p>I\'m not a teacher, but everyone looks for me once the break starts. I deal in sandwiches, not grades. I am the break-time hero. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/23.png', 14, 1, NOW()),

('Question 15', '<p>I carry the energy that keeps your project alive, without me, everything\'s just asleep.</p>', 'https://edu-books-images.b-cdn.net/robo/12.png', 15, 1, NOW()),

('Question 16', '<p>I never stop turning, but I never get dizzy. I\'m the reason your RC car moves forward. What am I?</p>', 'https://edu-books-images.b-cdn.net/robo/16.png', 16, 1, NOW()),

('Question 17', '<p>I connect things like a good friend, only between the same type. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/13.png', 17, 1, NOW()),

('Question 18', '<p>Your next mission: pick up our RC car from the booth and find out how long it takes to walk (no running!) across the playground and back. Bring us the answer!</p>', 'https://edu-books-images.b-cdn.net/robo/24.png', 18, 1, NOW()),

('Question 19', '<p>I connect where no female can, my pins always find their match!</p>', 'https://edu-books-images.b-cdn.net/robo/14.png', 19, 1, NOW()),

('Question 20', '<p>It\'s not a physics formula, not a math problem, not even the smell of burnt circuits… but this single word can make every STEM student start typing at light speed. What is it?</p>', 'https://edu-books-images.b-cdn.net/robo/25.png', 20, 1, NOW()),

('Question 21', '<p>I\'m the reason your RC listens to your phone, wireless and proud. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/15.png', 21, 1, NOW()),

('Question 22', '<p>I\'m round, tough, and always ready to roll. Without me, your car\'s going nowhere.</p>', 'https://edu-books-images.b-cdn.net/robo/17.png', 22, 1, NOW()),

('Question 23', '<p>I\'m the only mammal that can\'t jump, not even a tiny hop, yet I can push down trees and shake the ground when I walk. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/26.png', 23, 1, NOW()),

('Question 24', '<p>I turn power from the motor into motion on the ground — no me, no speed. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/18.png', 24, 1, NOW()),

('Question 25', '<p>My fingerprints are so close to a human\'s that even detectives could get confused. I live in trees, eat leaves, and have a suspiciously calm expression. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/27.png', 25, 1, NOW()),

('Question 26', '<p>I\'m simple but essential — I keep the car rolling smoothly while others just spin air. What am I?</p>', 'https://edu-books-images.b-cdn.net/robo/19.png', 26, 1, NOW()),

('Question 27', '<p>I\'m technically a fruit, used in salads and sauces, but here\'s the twist: I have more genes than you. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/28.png', 27, 1, NOW()),

('Question 28', '<p>Without me, your car would collapse faster than a weak circuit. I keep the whole structure solid. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/2.png', 28, 1, NOW()),

('Question 29', '<p>Every planet spins the same way… except me. I like doing things backwards — even the Sun rises on my \'wrong\' side. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/29.png', 29, 1, NOW()),

('Question 30', '<p>I bleed blue, not because I\'m royal — but because I use copper instead of iron in my blood. Ancient, armored, and oddly elegant — who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/30.png', 30, 1, NOW()),

('Question 31', '<p>This sensor helps a robot avoid bumping into walls — it\'s not magic, just sound waves. What\'s it called?</p>', 'https://edu-books-images.b-cdn.net/robo/32.png', 31, 1, NOW()),

('Question 32', '<p>I have three hearts, blue blood, and eight arms, and when things get stressful, I vanish in a cloud of ink. Who am I?</p>', 'https://edu-books-images.b-cdn.net/robo/31.png', 32, 1, NOW()),

('Question 33', '<p>Your robot can move forward and backward but turns like a confused turtle. Which component are you probably missing?</p>', 'https://edu-books-images.b-cdn.net/robo/33.png', 33, 1, NOW()),

('Question 34', '<p>If a robot had a favorite organ, which one would it be, the one that gives it a brain to think?</p>', 'https://edu-books-images.b-cdn.net/robo/34.png', 34, 1, NOW()),

('Question 35', '<p>This motor type doesn\'t spin freely, it\'s all about steps, precision, and patience. What\'s it called?</p>', 'https://edu-books-images.b-cdn.net/robo/35.png', 35, 1, NOW()),

('Question 36', '<p>When robots need to \'see\' the world, they don\'t use eyes. They use… what?</p>', 'https://edu-books-images.b-cdn.net/robo/36.png', 36, 1, NOW()),

('Question 37', '<p>You tell your robot to move 10 cm forward, but it goes 11 cm and knocks over a cup. Which sensor could\'ve saved your drink?</p>', 'https://edu-books-images.b-cdn.net/robo/37.png', 37, 1, NOW());

-- Verify the insert
SELECT COUNT(*) as total_questions FROM questions WHERE is_active = 1;

-- Show all inserted questions
SELECT id, title, display_order, is_active FROM questions ORDER BY display_order;
