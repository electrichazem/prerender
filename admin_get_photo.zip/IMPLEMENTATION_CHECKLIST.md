# Frontend Implementation Checklist

## ✅ Pre-Implementation Setup

- [ ] **Database Update**: Run `database_update.sql` on your MySQL database
- [ ] **Photo Folder**: Ensure `uploads/photos/` directory exists and is writable
- [ ] **API Testing**: Test all new endpoints with Postman/curl
- [ ] **Token Management**: Verify admin and team token systems work

---

## 🎨 UI/UX Updates Required

### 1. Question Status Display
- [ ] Update question cards to show new statuses:
  - `available` → Green "Submit Answer" button
  - `pending_answer` → Yellow "Answer Pending" badge
  - `hint_unlocked` → Blue "Take Photo" button
  - `pending_photo` → Orange "Photo Pending" badge
  - `completed` → Purple "Completed" badge

### 2. Progress Dashboard
- [ ] Update progress statistics to show:
  - Completed questions (fully solved)
  - Hint unlocked (can take photos)
  - Pending answers
  - Pending photos
  - Available questions

### 3. Action Buttons
- [ ] Implement conditional button display:
  - Show "Submit Answer" when `can_submit_answer: true`
  - Show "Take Photo" when `can_submit_photo: true`
  - Hide both when question is completed

---

## 📱 Photo Upload Implementation

### 1. Camera Integration
- [ ] **Mobile Web**: Implement camera capture using `<input type="file" capture="environment">`
- [ ] **React Native**: Use `react-native-image-picker` or similar
- [ ] **Desktop**: File upload with image preview
- [ ] **Validation**: Check file size and format before upload

### 2. Photo Upload Component
- [ ] Create reusable photo upload component
- [ ] Handle base64 encoding/decoding
- [ ] Show upload progress indicator
- [ ] Display captured photo preview
- [ ] Handle upload errors gracefully

### 3. Photo Preview
- [ ] Show submitted photos in question details
- [ ] Display photo status (pending/accepted/rejected)
- [ ] Show admin notes for photo submissions

---

## 🔧 Admin Panel Updates

### 1. Submission Review Interface
- [ ] **Tab System**: Separate tabs for "Answer Review" and "Photo Review"
- [ ] **Photo Viewer**: Display photos in admin review interface
- [ ] **Review Actions**: Accept/reject buttons for both answer and photo
- [ ] **Admin Notes**: Text area for admin feedback

### 2. Dashboard Statistics
- [ ] Update admin dashboard to show:
  - Total completed questions
  - Photos pending review
  - Answer vs photo completion rates

### 3. Submission List
- [ ] Show photo submission indicators
- [ ] Display photo status badges
- [ ] Add photo review quick actions

---

## 🔄 State Management Updates

### 1. Question State
- [ ] Update question state to include:
  ```javascript
  {
    status: 'hint_unlocked',
    can_submit_answer: false,
    can_submit_photo: true,
    answer_status: 'accepted',
    photo_status: 'pending',
    photo_filename: 'team_5_question_123_1698123456.jpg'
  }
  ```

### 2. Progress State
- [ ] Update progress tracking:
  ```javascript
  {
    completed: 3,
    hint_unlocked: 2,
    pending_answer: 1,
    pending_photo: 1,
    available: 3
  }
  ```

### 3. Submission State
- [ ] Track photo submissions separately from answers
- [ ] Handle photo review status updates
- [ ] Manage photo file references

---

## 🌐 API Integration

### 1. New Endpoints
- [ ] **Submit Photo**: `POST /submit_photo.php`
- [ ] **Get Photo**: `GET /admin_get_photo.php`
- [ ] **Review Photo**: Update `admin_review_submission.php` with `review_type`

### 2. Updated Endpoints
- [ ] **Team Progress**: Handle new response structure
- [ ] **Question Detail**: Process new photo-related fields
- [ ] **Admin Submissions**: Display photo information
- [ ] **Admin Questions**: Show photo statistics

### 3. Error Handling
- [ ] Handle new error cases:
  - "Hint not unlocked yet"
  - "Photo already submitted"
  - "Photo file not found"
- [ ] Show appropriate error messages to users

---

## 📱 Mobile-Specific Tasks

### 1. Camera Permissions
- [ ] Request camera permissions on mobile
- [ ] Handle permission denied gracefully
- [ ] Provide fallback to file upload

### 2. Image Optimization
- [ ] Compress images before upload
- [ ] Resize images for mobile screens
- [ ] Handle different image orientations

### 3. Upload Handling
- [ ] Show upload progress on mobile
- [ ] Handle network interruptions
- [ ] Retry failed uploads

---

## 🧪 Testing Checklist

### 1. Student Flow Testing
- [ ] Submit answer → Wait for admin approval
- [ ] Hint unlocks → Take photo → Submit photo
- [ ] Photo accepted → Question marked as completed
- [ ] Test photo rejection → Can resubmit photo

### 2. Admin Flow Testing
- [ ] Review answer submissions
- [ ] Accept answer → Hint unlocks for student
- [ ] Review photo submissions
- [ ] Accept photo → Question completed
- [ ] Test rejection flows

### 3. Edge Cases
- [ ] Multiple photo submissions
- [ ] Network failures during upload
- [ ] Invalid image formats
- [ ] Large file uploads
- [ ] Concurrent submissions

---

## 🚀 Deployment Checklist

### 1. Backend Deployment
- [ ] Database schema updated
- [ ] Photo upload directory created
- [ ] File permissions set correctly
- [ ] New PHP files deployed

### 2. Frontend Deployment
- [ ] New components built and tested
- [ ] API integration tested
- [ ] Mobile responsiveness verified
- [ ] Error handling tested

### 3. Production Testing
- [ ] End-to-end flow tested
- [ ] Photo upload working
- [ ] Admin review process working
- [ ] Performance acceptable

---

## 📋 Post-Deployment

### 1. Monitoring
- [ ] Monitor photo upload success rates
- [ ] Track admin review times
- [ ] Monitor storage usage
- [ ] Check for any errors in logs

### 2. User Feedback
- [ ] Gather feedback from students
- [ ] Collect admin feedback
- [ ] Monitor user experience
- [ ] Identify any issues

### 3. Optimization
- [ ] Optimize photo compression
- [ ] Improve upload performance
- [ ] Enhance mobile experience
- [ ] Add any missing features

---

## 🆘 Troubleshooting Guide

### Common Issues:
1. **Photo Upload Fails**: Check file permissions and directory existence
2. **Hint Not Unlocking**: Verify answer was accepted by admin
3. **Photo Not Displaying**: Check admin_get_photo.php endpoint
4. **Status Not Updating**: Verify API responses include new fields

### Debug Steps:
1. Check browser console for errors
2. Verify API responses in Network tab
3. Test endpoints with Postman
4. Check server logs for PHP errors

---

This checklist should help ensure a smooth implementation of the two-phase completion system!
