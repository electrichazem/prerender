<?php
include 'config.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

// Get input data
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$question_id = isset($input['question_id']) ? intval($input['question_id']) : 0;
$photo_data = isset($input['photo_data']) ? $input['photo_data'] : ''; // Base64 encoded image

if ($question_id <= 0 || empty($photo_data)) {
    http_response_code(400);
    echo json_encode(["error" => "Question ID and photo data are required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token and get team ID
    $team_query = "SELECT id FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Check if question exists, is active, and not globally completed
    $question_query = "
        SELECT q.id,
               CASE WHEN EXISTS(
                   SELECT 1 FROM submissions s 
                   WHERE s.question_id = q.id AND s.photo_status = 'accepted'
               ) THEN 1 ELSE 0 END as is_globally_completed
        FROM questions q 
        WHERE q.id = :question_id AND q.is_active = 1";
    $stmt = $db->prepare($question_query);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $question = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$question) {
        http_response_code(404);
        echo json_encode(["error" => "Question not found or inactive"]);
        exit;
    }

    // Check if question is globally completed by another team
    if ($question['is_globally_completed']) {
        http_response_code(403);
        echo json_encode(["error" => "Question has been completed by another team"]);
        exit;
    }

    // Check if team has an accepted submission for this question (hint unlocked)
    $submission_query = "SELECT id, status FROM submissions 
                        WHERE team_id = :team_id AND question_id = :question_id AND status = 'accepted'";
    $stmt = $db->prepare($submission_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->bindParam(':question_id', $question_id, PDO::PARAM_INT);
    $stmt->execute();
    $submission = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$submission) {
        http_response_code(403);
        echo json_encode(["error" => "Hint not unlocked yet. Answer must be accepted first."]);
        exit;
    }

    // Check if photo already submitted
    $photo_check_query = "SELECT photo_status FROM submissions 
                         WHERE id = :submission_id AND photo_status IS NOT NULL";
    $stmt = $db->prepare($photo_check_query);
    $stmt->bindParam(':submission_id', $submission['id'], PDO::PARAM_INT);
    $stmt->execute();
    $photo_status = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($photo_status) {
        if ($photo_status['photo_status'] === 'accepted') {
            http_response_code(409);
            echo json_encode(["error" => "Photo already accepted. Question completely solved."]);
            exit;
        } else if ($photo_status['photo_status'] === 'pending') {
            http_response_code(409);
            echo json_encode(["error" => "Photo already submitted and pending review"]);
            exit;
        }
        // If rejected, allow resubmission
    }

    // Process photo data (base64 to file)
    if (strpos($photo_data, 'data:image/') === 0) {
        // Remove data URL prefix
        $photo_data = substr($photo_data, strpos($photo_data, ',') + 1);
    }
    
    $decoded_photo = base64_decode($photo_data);
    if ($decoded_photo === false) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid photo data"]);
        exit;
    }

    // Generate unique filename
    $filename = 'team_' . $team_id . '_question_' . $question_id . '_' . time() . '.jpg';
    $filepath = 'uploads/photos/' . $filename;

    // Save photo to file
    if (file_put_contents($filepath, $decoded_photo) === false) {
        http_response_code(500);
        echo json_encode(["error" => "Failed to save photo"]);
        exit;
    }

    // Update submission with photo information
    $update_query = "UPDATE submissions 
                    SET photo_filename = :filename, 
                        photo_submitted_at = NOW(), 
                        photo_status = 'pending'
                    WHERE id = :submission_id";
    
    $stmt = $db->prepare($update_query);
    $stmt->bindParam(':filename', $filename, PDO::PARAM_STR);
    $stmt->bindParam(':submission_id', $submission['id'], PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "Photo submitted successfully and pending review",
        "filename" => $filename,
        "submission_id" => $submission['id']
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>
