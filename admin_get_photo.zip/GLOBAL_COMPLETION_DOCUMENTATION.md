# Global Question Completion Feature - Documentation

## Overview
This update implements a **global question completion system** where once ANY team completes a question (photo accepted), that question becomes **locked for all other teams**. This creates a competitive "first to solve" environment.

---

## 🎯 **What Changed**

### **Before:**
- Each team could solve questions independently
- Multiple teams could complete the same question
- No global competition element

### **After:**
- **First team to complete wins** - question locks globally
- Other teams cannot submit answers or photos
- Clear competitive element added

---

## 🔒 **How Global Completion Works**

### **Completion Trigger:**
When an admin accepts a photo submission (`photo_status = 'accepted'`), the question becomes globally completed.

### **Lock Mechanism:**
- SQL query checks: `EXISTS(SELECT 1 FROM submissions WHERE question_id = X AND photo_status = 'accepted')`
- If true → Question is globally completed
- All other teams blocked from further submissions

### **Real-time Effect:**
- Immediate lock when admin accepts photo
- No delay or caching issues
- All endpoints respect global completion status

---

## 📊 **Updated Status System**

### **New Question Statuses:**
```javascript
{
  'available': 'Can submit answer',
  'pending_answer': 'Answer submitted, waiting review', 
  'hint_unlocked': 'Answer accepted, can submit photo',
  'pending_photo': 'Photo submitted, waiting review',
  'completed': 'Photo accepted (individual team)',
  'globally_completed': 'Solved by another team (LOCKED)', // NEW
  'rejected': 'Answer/photo rejected, can resubmit'
}
```

### **Status Priority:**
1. **`globally_completed`** (highest priority)
2. Individual team statuses
3. `available` (lowest priority)

---

## 🔄 **Updated API Endpoints**

### **1. Get Team Progress** (`get_team_progress.php`)

**New Response Fields:**
```json
{
  "questions": [
    {
      "id": 123,
      "title": "Robot Assembly Challenge",
      "status": "globally_completed",        // NEW STATUS
      "can_submit_answer": false,            // Always false for global
      "can_submit_photo": false,             // Always false for global
      "is_globally_completed": true,         // NEW FIELD
      "answer_status": null,
      "photo_status": null
    }
  ]
}
```

**SQL Query Update:**
```sql
SELECT q.id, q.title, q.description_html, q.hint, q.display_order,
       CASE WHEN EXISTS(
           SELECT 1 FROM submissions s 
           WHERE s.question_id = q.id AND s.photo_status = 'accepted'
       ) THEN 1 ELSE 0 END as is_globally_completed
FROM questions q 
WHERE q.is_active = 1
```

---

### **2. Get Question Detail** (`get_question_detail.php`)

**New Response Fields:**
```json
{
  "question": {
    "id": 123,
    "status": "globally_completed",           // NEW STATUS
    "can_submit_answer": false,              // Always false for global
    "can_submit_photo": false,               // Always false for global
    "is_globally_completed": true,           // NEW FIELD
    "answer_status": null,
    "photo_status": null
  }
}
```

**Logic Update:**
```php
// Global completion takes precedence
if ($is_globally_completed) {
    $overall_status = 'globally_completed';
    $can_submit_answer = false;
    $can_submit_photo = false;
}
```

---

### **3. Submit Answer** (`submit_answer.php`)

**New Error Response:**
```json
{
  "error": "Question has been completed by another team"
}
```

**HTTP Status:** `403 Forbidden`

**Check Logic:**
```php
// Check if question is globally completed by another team
if ($question['is_globally_completed']) {
    http_response_code(403);
    echo json_encode(["error" => "Question has been completed by another team"]);
    exit;
}
```

---

### **4. Submit Photo** (`submit_photo.php`)

**New Error Response:**
```json
{
  "error": "Question has been completed by another team"
}
```

**HTTP Status:** `403 Forbidden`

**Same check logic as submit_answer.php**

---

## 🎨 **Frontend Implementation Guide**

### **1. Status Display Update**

```javascript
const getQuestionStatusBadge = (question) => {
  switch(question.status) {
    case 'available':
      return { text: 'Available', color: 'green', icon: 'play' };
    case 'pending_answer':
      return { text: 'Answer Pending', color: 'yellow', icon: 'clock' };
    case 'hint_unlocked':
      return { text: 'Take Photo', color: 'blue', icon: 'camera' };
    case 'pending_photo':
      return { text: 'Photo Pending', color: 'orange', icon: 'camera-clock' };
    case 'completed':
      return { text: 'Completed', color: 'purple', icon: 'check-circle' };
    case 'globally_completed':                    // NEW CASE
      return { text: 'Solved by Another Team', color: 'red', icon: 'lock' };
    default:
      return { text: 'Unknown', color: 'gray', icon: 'question' };
  }
};
```

### **2. Action Button Logic**

```javascript
const getAvailableActions = (question) => {
  const actions = [];
  
  // Global completion blocks all actions
  if (question.status === 'globally_completed') {
    return []; // No actions available
  }
  
  if (question.can_submit_answer) {
    actions.push({
      type: 'submit_answer',
      text: 'Submit Answer',
      icon: 'send',
      color: 'primary'
    });
  }
  
  if (question.can_submit_photo) {
    actions.push({
      type: 'submit_photo',
      text: 'Take Photo',
      icon: 'camera',
      color: 'secondary'
    });
  }
  
  return actions;
};
```

### **3. Question Card Component**

```javascript
const QuestionCard = ({ question }) => {
  const isGloballyCompleted = question.status === 'globally_completed';
  
  return (
    <div className={`question-card ${isGloballyCompleted ? 'locked' : ''}`}>
      <div className="question-header">
        <h3>{question.title}</h3>
        <StatusBadge status={question.status} />
      </div>
      
      {isGloballyCompleted ? (
        <div className="locked-message">
          <Icon name="lock" />
          <p>This question has been completed by another team</p>
        </div>
      ) : (
        <div className="question-actions">
          {getAvailableActions(question).map(action => (
            <ActionButton key={action.type} action={action} />
          ))}
        </div>
      )}
    </div>
  );
};
```

### **4. Error Handling**

```javascript
const handleSubmissionError = (error) => {
  if (error.includes('Question has been completed by another team')) {
    showNotification({
      type: 'warning',
      title: 'Question Completed',
      message: 'Another team has already solved this question!',
      duration: 5000
    });
    
    // Refresh question status
    refreshQuestionStatus();
  } else {
    // Handle other errors normally
    showError(error);
  }
};
```

---

## 📱 **UI/UX Considerations**

### **1. Visual Indicators**
- **Red color scheme** for globally completed questions
- **Lock icon** to indicate question is locked
- **Disabled state** for all interactive elements
- **Clear messaging** about why question is unavailable

### **2. User Experience**
- **Immediate feedback** when question becomes locked
- **Real-time updates** to show status changes
- **Helpful messaging** explaining the competitive nature
- **No confusion** about why actions are disabled

### **3. Mobile Considerations**
- **Touch-friendly** disabled states
- **Clear visual hierarchy** for locked questions
- **Accessible** color contrast for status indicators

---

## 🔧 **Admin Panel Updates**

### **1. Submission Review**
- **No changes needed** - admins can still review all submissions
- **Global completion** happens automatically when photo is accepted
- **Clear indication** when accepting a photo will lock the question

### **2. Question Management**
- **Question statistics** should show completion status
- **Dashboard** can highlight globally completed questions
- **Analytics** can track which team completed each question first

---

## 🧪 **Testing Scenarios**

### **1. Basic Flow Testing**
```
1. Team A submits answer → Admin accepts → Hint unlocked
2. Team A submits photo → Admin accepts → Question globally completed
3. Team B tries to submit answer → Should be blocked
4. Team C tries to submit photo → Should be blocked
5. All teams see question as 'globally_completed'
```

### **2. Edge Cases**
- **Concurrent submissions** - ensure only first photo acceptance locks question
- **Network delays** - verify real-time status updates
- **Multiple admins** - ensure consistent global completion logic
- **Database transactions** - verify atomic completion checks

### **3. Error Handling**
- **API errors** when submitting to completed questions
- **UI updates** when question status changes
- **User notifications** for blocked submissions

---

## 🚀 **Deployment Checklist**

### **Backend Deployment**
- [ ] Database schema supports photo_status column
- [ ] All PHP files updated with global completion logic
- [ ] SQL queries tested for performance
- [ ] Error responses properly formatted

### **Frontend Deployment**
- [ ] Status display updated for globally_completed
- [ ] Action buttons disabled for locked questions
- [ ] Error handling for blocked submissions
- [ ] UI styling for locked question states

### **Testing**
- [ ] End-to-end flow tested
- [ ] Multiple team scenarios verified
- [ ] Error cases handled properly
- [ ] Performance acceptable under load

---

## 📊 **Monitoring & Analytics**

### **Key Metrics**
- **Completion rate** - how many questions get globally completed
- **Team performance** - which teams complete questions first
- **Submission attempts** - how many blocked submissions occur
- **User experience** - error rates and user feedback

### **Logging**
- **Global completion events** - when questions get locked
- **Blocked submissions** - attempts to submit to completed questions
- **Admin actions** - photo acceptance that triggers global completion

---

## 🔄 **Migration Notes**

### **Existing Data**
- **No data migration needed** - existing submissions remain valid
- **Backward compatibility** - old submissions still work
- **Gradual rollout** - can be deployed without affecting existing games

### **Rollback Plan**
- **Remove global completion checks** from SQL queries
- **Revert to individual team status logic**
- **No data loss** - all submissions preserved

---

## 🆘 **Troubleshooting**

### **Common Issues**

1. **Question not locking after photo acceptance**
   - Check if `photo_status = 'accepted'` in database
   - Verify SQL query syntax
   - Check for database connection issues

2. **Teams can still submit to completed questions**
   - Verify global completion check is running
   - Check API endpoint error handling
   - Ensure frontend is checking `is_globally_completed`

3. **Status not updating in real-time**
   - Check API response includes new fields
   - Verify frontend state management
   - Test network connectivity

### **Debug Steps**
1. Check database for `photo_status = 'accepted'` records
2. Test SQL query manually
3. Verify API responses include global completion status
4. Check frontend console for errors
5. Test with multiple teams simultaneously

---

This documentation covers the complete global question completion feature implementation. The system now properly prevents other teams from solving questions once any team has completed them, creating a competitive "first to solve" environment!
