-- Database update for two-phase completion system
-- Run this script to update your database schema

-- Add new columns to submissions table for photo phase
ALTER TABLE submissions 
ADD COLUMN photo_filename VARCHAR(255) NULL AFTER admin_notes,
ADD COLUMN photo_submitted_at DATETIME NULL AFTER photo_filename,
ADD COLUMN photo_status ENUM('pending', 'accepted', 'rejected') NULL AFTER photo_submitted_at,
ADD COLUMN photo_reviewed_at DATETIME NULL AFTER photo_status,
ADD COLUMN photo_reviewed_by INT NULL AFTER photo_reviewed_at,
ADD COLUMN photo_admin_notes TEXT NULL AFTER photo_reviewed_by;

-- Add foreign key constraint for photo_reviewed_by
ALTER TABLE submissions 
ADD CONSTRAINT fk_submissions_photo_reviewed_by 
FOREIGN KEY (photo_reviewed_by) REFERENCES admin_users(id);

-- Update existing submissions to have photo_status as NULL (not applicable for old submissions)
-- This will be handled automatically by the new column definition

-- Add index for better performance
CREATE INDEX idx_submissions_photo_status ON submissions(photo_status);
CREATE INDEX idx_submissions_photo_submitted_at ON submissions(photo_submitted_at);
