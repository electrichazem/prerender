<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token
    $team_query = "SELECT id, name FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Get all unlocked hints with question info
    $hints_query = "SELECT q.id as question_id, q.title, q.hint, 
                   s.submitted_at, s.reviewed_at,
                   CASE WHEN s.reviewed_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE) 
                        THEN 1 ELSE 0 END as is_new
                   FROM submissions s 
                   JOIN questions q ON s.question_id = q.id 
                   WHERE s.team_id = :team_id AND s.status = 'accepted' 
                   ORDER BY s.reviewed_at DESC";
    $stmt = $db->prepare($hints_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->execute();
    $hints = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Count new hints (reviewed in last 5 minutes)
    $new_hints = array_filter($hints, function($hint) {
        return $hint['is_new'] == 1;
    });

    echo json_encode([
        "success" => true,
        "hints" => $hints,
        "total_hints" => count($hints),
        "new_hints_count" => count($new_hints),
        "last_updated" => date('Y-m-d H:i:s')
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>