<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Verify admin token
$headers = getallheaders();
$admin_token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($admin_token)) {
    http_response_code(401);
    echo json_encode(["error" => "Admin token required"]);
    exit;
}

$submission_id = isset($_GET['submission_id']) ? intval($_GET['submission_id']) : 0;

if ($submission_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Valid submission ID is required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify admin
    $admin_query = "SELECT id FROM admin_users WHERE admin_token = :token AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid admin token"]);
        exit;
    }

    // Get submission with photo info
    $submission_query = "
        SELECT s.id, s.photo_filename, s.photo_status, s.photo_submitted_at,
               t.name as team_name, q.title as question_title
        FROM submissions s
        JOIN teams t ON s.team_id = t.id
        JOIN questions q ON s.question_id = q.id
        WHERE s.id = :submission_id AND s.photo_filename IS NOT NULL
    ";
    $stmt = $db->prepare($submission_query);
    $stmt->bindParam(':submission_id', $submission_id, PDO::PARAM_INT);
    $stmt->execute();
    $submission = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$submission) {
        http_response_code(404);
        echo json_encode(["error" => "Photo submission not found"]);
        exit;
    }

    $photo_path = 'uploads/photos/' . $submission['photo_filename'];
    
    if (!file_exists($photo_path)) {
        http_response_code(404);
        echo json_encode(["error" => "Photo file not found"]);
        exit;
    }

    // Get photo data and encode as base64
    $photo_data = base64_encode(file_get_contents($photo_path));
    $photo_mime_type = mime_content_type($photo_path);

    echo json_encode([
        "success" => true,
        "submission" => [
            "id" => $submission['id'],
            "team_name" => $submission['team_name'],
            "question_title" => $submission['question_title'],
            "photo_status" => $submission['photo_status'],
            "photo_submitted_at" => $submission['photo_submitted_at'],
            "photo_data" => "data:" . $photo_mime_type . ";base64," . $photo_data,
            "filename" => $submission['photo_filename']
        ]
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>
