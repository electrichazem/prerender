<?php
include 'config.php';

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get token from header
$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

if (empty($token)) {
    http_response_code(401);
    echo json_encode(["error" => "Authorization token required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Verify team token
    $team_query = "SELECT id, name FROM teams WHERE token = :token AND is_active = 1";
    $stmt = $db->prepare($team_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid or expired token"]);
        exit;
    }

    $team_id = $team['id'];

    // Get all active questions and check if they're globally completed
    $questions_query = "
        SELECT q.id, q.title, q.description_html, q.hint, q.display_order,
               CASE WHEN EXISTS(
                   SELECT 1 FROM submissions s 
                   WHERE s.question_id = q.id AND s.photo_status = 'accepted'
               ) THEN 1 ELSE 0 END as is_globally_completed
        FROM questions q 
        WHERE q.is_active = 1 
        ORDER BY q.display_order";
    $stmt = $db->prepare($questions_query);
    $stmt->execute();
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get team's submissions with photo status
    $submissions_query = "SELECT question_id, status, photo_status 
                         FROM submissions 
                         WHERE team_id = :team_id";
    $stmt = $db->prepare($submissions_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->execute();
    $submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate progress
    $solved_count = 0;
    $hint_unlocked_count = 0;
    $pending_answer_count = 0;
    $pending_photo_count = 0;
    $submission_map = [];

    foreach ($submissions as $sub) {
        $question_id = $sub['question_id'];
        $status = $sub['status'];
        $photo_status = $sub['photo_status'];
        
        // Determine overall status for this question
        if ($photo_status === 'accepted') {
            $overall_status = 'completed';
            $solved_count++;
        } else if ($status === 'accepted' && $photo_status === 'pending') {
            $overall_status = 'hint_unlocked';
            $hint_unlocked_count++;
        } else if ($status === 'accepted' && $photo_status === 'rejected') {
            $overall_status = 'hint_unlocked';
            $hint_unlocked_count++;
        } else if ($status === 'pending') {
            $overall_status = 'pending_answer';
            $pending_answer_count++;
        } else if ($status === 'accepted' && $photo_status === null) {
            $overall_status = 'hint_unlocked';
            $hint_unlocked_count++;
        } else {
            $overall_status = $status;
        }
        
        $submission_map[$question_id] = [
            'status' => $overall_status,
            'answer_status' => $status,
            'photo_status' => $photo_status
        ];
    }

    // Prepare questions with status
    $questions_with_status = [];
    foreach ($questions as $question) {
        $submission_data = isset($submission_map[$question['id']]) ? $submission_map[$question['id']] : null;
        $is_globally_completed = (bool)$question['is_globally_completed'];
        
        // Determine status - global completion takes precedence
        if ($is_globally_completed) {
            $status = 'globally_completed';
            $can_submit_answer = false;
            $can_submit_photo = false;
        } else {
            $status = $submission_data ? $submission_data['status'] : 'available';
            
            // Determine what actions are available
            $can_submit_answer = false;
            $can_submit_photo = false;
            
            if ($status === 'available' || $status === 'rejected') {
                $can_submit_answer = true;
            } else if ($status === 'hint_unlocked') {
                $can_submit_photo = true;
            }
        }
        
        $questions_with_status[] = [
            'id' => $question['id'],
            'title' => $question['title'],
            'description_html' => $question['description_html'],
            'hint' => $question['hint'],
            'display_order' => $question['display_order'],
            'status' => $status,
            'can_submit_answer' => $can_submit_answer,
            'can_submit_photo' => $can_submit_photo,
            'answer_status' => $submission_data ? $submission_data['answer_status'] : null,
            'photo_status' => $submission_data ? $submission_data['photo_status'] : null,
            'is_globally_completed' => $is_globally_completed
        ];
    }
    // Get unlocked hints (accepted submissions)
    $hints_query = "SELECT q.id as question_id, q.title, q.hint, s.submitted_at, s.photo_status
    FROM submissions s 
    JOIN questions q ON s.question_id = q.id 
    WHERE s.team_id = :team_id AND s.status = 'accepted' 
    ORDER BY s.reviewed_at DESC";
    $stmt = $db->prepare($hints_query);
    $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
    $stmt->execute();
    $unlocked_hints = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Count new hints since last check
    $last_check = isset($_GET['last_check']) ? $_GET['last_check'] : null;
    $new_hints_count = 0;

    if ($last_check) {
        $new_hints_query = "SELECT COUNT(*) as new_count 
                FROM submissions s 
                WHERE s.team_id = :team_id 
                AND s.status = 'accepted' 
                AND s.reviewed_at > :last_check";
        $stmt = $db->prepare($new_hints_query);
        $stmt->bindParam(':team_id', $team_id, PDO::PARAM_INT);
        $stmt->bindParam(':last_check', $last_check, PDO::PARAM_STR);
        $stmt->execute();
        $new_hints_result = $stmt->fetch(PDO::FETCH_ASSOC);
        $new_hints_count = $new_hints_result['new_count'];
    }
    
    echo json_encode([
        "success" => true,
        "team_name" => $team['name'],
        "progress" => [
            "total_questions" => count($questions),
            "completed" => $solved_count,
            "hint_unlocked" => $hint_unlocked_count,
            "pending_answer" => $pending_answer_count,
            "pending_photo" => $pending_photo_count,
            "available" => count($questions) - $solved_count - $hint_unlocked_count - $pending_answer_count - $pending_photo_count
        ],
        "questions" => $questions_with_status,
        "unlocked_hints" => $unlocked_hints,
        "new_hints_count" => $new_hints_count,
        "last_updated" => date('Y-m-d H:i:s')
    ]);
} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>