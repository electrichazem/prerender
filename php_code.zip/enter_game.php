<?php

include 'config.php';



// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get and validate input
$input = json_decode(file_get_contents('php://input'), true);
$team_code = isset($input['team_code']) ? trim($input['team_code']) : '';

if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Team code is required"]);
    exit;
}

// Sanitize team code (alphanumeric only)
$team_code = preg_replace('/[^a-zA-Z0-9]/', '', $team_code);
if (empty($team_code)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid team code format"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Check if any active questions exist
    $check_questions_query = "SELECT COUNT(*) as active_count FROM questions WHERE is_active = 1";
    $stmt = $db->prepare($check_questions_query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['active_count'] == 0) {
        http_response_code(403);
        echo json_encode(["error" => "Game has not started or all questions have been solved"]);
        exit;
    }

    // Check if team exists and is not already registered
    $check_team_query = "SELECT id, name, token FROM teams WHERE code = :code AND is_active = 1";
    $stmt = $db->prepare($check_team_query);
    $stmt->bindParam(':code', $team_code, PDO::PARAM_STR);
    $stmt->execute();
    $team = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$team) {
        http_response_code(404);
        echo json_encode(["error" => "Team not found or inactive"]);
        exit;
    }

    // If team already has a token, they can't register again
    if (!empty($team['token'])) {
        http_response_code(409);
        echo json_encode(["error" => "Team already registered. Token already exists."]);
        exit;
    }

    // Generate unique token
    $token = bin2hex(random_bytes(32)); // 64-character secure token
    
    // Update team with token
    $update_query = "UPDATE teams SET token = :token, last_activity = NOW() WHERE id = :id AND token IS NULL";
    $stmt = $db->prepare($update_query);
    $stmt->bindParam(':token', $token, PDO::PARAM_STR);
    $stmt->bindParam(':id', $team['id'], PDO::PARAM_INT);
    
    if ($stmt->execute() && $stmt->rowCount() > 0) {
        // Successfully registered
        echo json_encode([
            "success" => true,
            "message" => "Team successfully entered the game",
            "team_name" => $team['name'],
            "token" => $token
        ]);
    } else {
        // Race condition: someone else registered this team between our checks
        http_response_code(409);
        echo json_encode(["error" => "Team already registered"]);
    }

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
} catch(Exception $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Server error: " . $exception->getMessage()]);
}
?>