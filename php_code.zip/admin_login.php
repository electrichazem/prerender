<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid JSON input"]);
    exit;
}

$username = isset($input['username']) ? trim($input['username']) : '';
$password = isset($input['password']) ? trim($input['password']) : '';

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(["error" => "Username and password are required"]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // Find admin user
    $admin_query = "SELECT id, username, password_hash FROM admin_users 
                   WHERE username = :username AND is_active = 1";
    $stmt = $db->prepare($admin_query);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid credentials"]);
        exit;
    }

    // Verify password
    if (!password_verify($password, $admin['password_hash'])) {
        http_response_code(401);
        echo json_encode(["error" => "Invalid credentials"]);
        exit;
    }

    // Generate admin token (similar to team tokens but separate)
    $admin_token = bin2hex(random_bytes(32));
    
    // Store token in database (simple approach)
    $update_token_query = "UPDATE admin_users SET admin_token = :token WHERE id = :id";
    $stmt = $db->prepare($update_token_query);
    $stmt->bindParam(':token', $admin_token, PDO::PARAM_STR);
    $stmt->bindParam(':id', $admin['id'], PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        "success" => true,
        "message" => "Admin login successful",
        "admin_token" => $admin_token,
        "username" => $admin['username']
    ]);

} catch(PDOException $exception) {
    http_response_code(500);
    echo json_encode(["error" => "Database error: " . $exception->getMessage()]);
}
?>